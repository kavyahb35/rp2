<?php
	
 	$Usedstaticdata = false;
	if($Usedstaticdata==true){
		return [	
		'Base_Url' => 'http://localhost/04laravel/R2P/',
		'PartnerId' =>'CA_R2P_011',
		'PartnerName' => 'Rewards2Pay Inc',
		'Sendbox_Url' =>'https://www.sandbox.paypal.com/cgi-bin/webscr',
		'Usedstaticdata' =>$Usedstaticdata,
		'Api_Url' =>'http://localhost/04laravel/R2P/'
		];
	}else{
		return [	
		'Base_Url' => 'http://localhost/04laravel/R2P/',
		'PartnerId' =>'CA_R2P_011',
		'PartnerName' => 'Rewards2Pay Inc',
		'Sendbox_Url' =>'https://www.sandbox.paypal.com/cgi-bin/webscr',
		'Usedstaticdata' =>$Usedstaticdata,
		'Api_Url' =>'https://gajendrachhipa-trial-test.apigee.net/'
		];
	}

	
   
