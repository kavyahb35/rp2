<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" name="frmTransaction" id="frmTransaction">
    <input type="hidden" name="business" value="sumit@cueserve.com"> 
    <input type="hidden" name="cmd" value="_xclick"> 
     <input type="hidden" name="item_name" value="test watch"> 
    <input type="hidden" name="item_number" value="1">
    <input type="hidden" name="amount" value="2">   
    <input type="hidden" name="currency_code" value="USD">   
    <input type="hidden" name="cancel_return" value="http://localhost/04laravel/R2P/payment-cancel"> 
    <input type="hidden" name="return" value="http://localhost/04laravel/R2P/payment-status">
    
</form>
<SCRIPT>document.frmTransaction.submit();</SCRIPT> 
