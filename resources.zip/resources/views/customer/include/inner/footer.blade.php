
    <footer class="footer footer-static footer-transparent">
      <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright  &copy; 2018 <a class="text-bold-800 grey darken-2" href="" target="_blank">Rewards2pay.com </a>, All rights reserved. </span>
      </p>
    </footer>
      <!-- BEGIN VENDOR JS-->
    <script src="{{ url() }}/public/front/customer/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>

    <script src="{{ url() }}/public/front/customer/app-assets/js/core/app-menu.js" type="text/javascript"></script>
    <script src="{{ url() }}/public/front/customer/app-assets/js/core/app.js" type="text/javascript"></script>

</body>
</html>
