<nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-light navbar-bg-color customer-layout">
   <div class="navbar-wrapper">
      <div class="navbar-header d-md-none">
         <ul class="nav navbar-nav flex-row">
            <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
            <li class="nav-item d-md-none"><a class="navbar-brand" href="{{ url('dashboard') }}"><img class="brand-logo d-none d-md-block" alt="R2P logo" src="{{ url( )}}/public/front/customer/app-assets/images/logo/logo.png">
            <img class="brand-logo d-sm-block d-md-none" alt="R2P logo sm" src="{{ url( )}}public/front/customer/app-assets/images/logo/logo-sm.png"></a></li>
            <li class="nav-item d-md-none"><a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v">   </i></a></li>
         </ul>
      </div>
      <div class="navbar-container">
         <div class="collapse navbar-collapse" id="navbar-mobile">
            <ul class="nav navbar-nav mr-auto float-left">
               <li class="nav-item d-none d-md-block left-li"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu">         </i></a></li>
               <li class="nav-item nav-search left-li">
                  <div class="">
                     
                  </div>
               </li>
            </ul>
            <ul class="nav navbar-nav float-right">
             
               <li class="dropdown dropdown-notification nav-item right-li"><a class="nav-link nav-link-label" href="{{ url('/wallet') }}"><i class="ficon icon-wallet"></i></a></li>
               <li class="dropdown dropdown-user nav-item right-li">
                  <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">             
					<span class="avatar avatar-online">
						<img src="{{ url( )}}/public/front/customer/app-assets/images/portrait/small/avatar-user.png" alt="r2p" />
					</span>
					<span class="mr-1"><?php echo  session()->get('cfirstName');?></span>
				  </a>
                  <div class="dropdown-menu dropdown-menu-right">
                     <a class="dropdown-item" href=""><i class="ft-award"></i><?php 
                     
                        $firstName = session()->get('cfirstName');

                        $lastName = session()->get('clastName');
                        echo $firstName.' '.$lastName;
                                     ?></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="{{ url('/profile') }}"><i class="ft-user"></i> Profile</a>

                    <a class="dropdown-item" href="{{ url('/change-password') }}"><i class="ft-lock"></i> Change Password</a>
                    <a class="dropdown-item" href="{{ url('/wallet') }}"><i class="icon-wallet"></i> My Wallet</a><a class="dropdown-item" href="{{ url('/transaction') }}"><i class="ft-check-square"></i> Transactions              </a>
                    <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="{{ url('logout') }}"><i class="ft-power"></i> Logout</a>
                  </div>
               </li>
            </ul>
         </div>
      </div>
   </div>
</nav>
<div class="main-menu menu-fixed menu-dark menu-bg-default rounded menu-accordion menu-shadow">
   <div class="main-menu-content">
      <a class="navigation-brand d-none d-md-block d-lg-block d-xl-block" href=""><img class="brand-logo" alt="r2p logo" src="{{ url() }}/public/front/customer/app-assets/images/logo/logo.png"/></a>
      <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
          <li @if(Request::url() === url('/dashboard')) class="active" @endif ><a href="{{ url('/dashboard') }}"><i class="icon-grid"></i><span class="menu-title" data-i18n="">Dashboard</span></a>
         </li>
         <li @if(Request::url() === url('/manage-cards')) class="active" @endif ><a href="{{ url('/manage-cards') }} "><i class="icon-layers"></i><span class="menu-title" data-i18n="">Cards</span></a>
         </li>
         <li @if(Request::url() === url('/wallet')) class="active" @endif ><a href="{{ url('/wallet') }} "><i class="icon-wallet"></i><span class="menu-title" data-i18n="">Wallet</span></a>
         </li>
         <li @if(Request::url() === url('/transaction')) class="active" @endif ><a href="{{ url('/transaction') }} "><i class="icon-shuffle"></i><span class="menu-title" data-i18n="">Transactions</span></a>
         </li>
         <li class=" nav-item"><a href=""><i class="icon-support"></i><span class="menu-title" data-i18n="">FAQ</span></a>
         </li>
         <li class=" nav-item">
            <a href="{{ url('/profile') }}"><i class="icon-user-following"></i><span class="menu-title" data-i18n="">Account</span></a>
          
         </li>
      </ul>
   </div>
</div>
