<?php header("Cache-Control: max-age=300, must-revalidate");?>
<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <head><title>R2p</title>
  <meta name="csrf-token" content="{{ csrf_token() }}">
   <meta name="description" content="<?php //echo $metadescription;?>">
    <meta name="keywords" content="<?php //echo $metakeyword;?>">
    <meta name="author" content="PIXINVENT">    
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
   


 <link rel="apple-touch-icon" href="{{ url() }}/public/front/customer/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="{{ url() }}/public/front/customer/app-assets/images/ico/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,300i,400,400i,600,600i,700,700i|Comfortaa:300,400,500,700" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/app-assets/css/vendors.css">
    <!--<link rel="stylesheet" type="text/css" href="{{ url() }}/public/assets/front/customer/app-assets/vendors/css/charts/chartist.css">
    <link rel="stylesheet" type="text/css" href="{{ url() }}/public/assets/front/customer/app-assets/vendors/css/charts/chartist-plugin-tooltip.css">-->
    <!-- END VENDOR CSS-->
    <!-- BEGIN MODERN CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/app-assets/css/app.css">
    <!-- END MODERN CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/app-assets/css/core/menu/menu-types/vertical-compact-menu.css">
    <link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/app-assets/vendors/css/cryptocoins/cryptocoins.css">
    <link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/app-assets/css/pages/timeline.css">
    <link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/app-assets/css/pages/dashboard-ico.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    
	<link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>-->
	<script src="{{ url() }}/public/front/home/assets/js/datetimepicker/jquery-2.1.1.min.js"></script>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
	<script src="{{ url() }}/public/front/customer/assets/js/jquery-confirm.min.js"></script>
	<link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/assets/css/jquery-confirm.min.css">
	<?php
	/*function getBrowser() 
	{ 
		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
		$bname = 'Unknown';
		$platform = 'Unknown';
		$version= "";

		//First get the platform?
		if (preg_match('/linux/i', $u_agent)) {
			$platform = 'linux';
		}
		elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
			$platform = 'mac';
		}
		elseif (preg_match('/windows|win32/i', $u_agent)) {
			$platform = 'windows';
		}

		// Next get the name of the useragent yes seperately and for good reason
		if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) 
		{ 
			$bname = 'Internet Explorer'; 
			$ub = "MSIE"; 
		} 
		elseif(preg_match('/Firefox/i',$u_agent)) 
		{ 
			$bname = 'Mozilla Firefox'; 
			$ub = "Firefox"; 
		}
		elseif(preg_match('/OPR/i',$u_agent)) 
		{ 
			$bname = 'Opera'; 
			$ub = "Opera"; 
		} 
		elseif(preg_match('/Chrome/i',$u_agent)) 
		{ 
			$bname = 'Google Chrome'; 
			$ub = "Chrome"; 
		} 
		elseif(preg_match('/Safari/i',$u_agent)) 
		{ 
			$bname = 'Apple Safari'; 
			$ub = "Safari"; 
		} 
		elseif(preg_match('/Netscape/i',$u_agent)) 
		{ 
			$bname = 'Netscape'; 
			$ub = "Netscape"; 
		} 

		// finally get the correct version number
		$known = array('Version', $ub, 'other');
		$pattern = '#(?<browser>' . join('|', $known) .
		')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
		if (!preg_match_all($pattern, $u_agent, $matches)) {
			// we have no matching number just continue
		}

		// see how many we have
		$i = count($matches['browser']);
		if ($i != 1) {
			//we will have two since we are not using 'other' argument yet
			//see if version is before or after the name
			if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
				$version= $matches['version'][0];
			}
			else {
				$version= $matches['version'][1];
			}
		}
		else {
			$version= $matches['version'][0];
		}

		// check if we have a number
		if ($version==null || $version=="") {$version="?";}

		return array(
			'userAgent' => $u_agent,
			'name'      => $bname,
			'version'   => $version,
			'platform'  => $platform,
			'pattern'    => $pattern
		);
	} 
	
	$ua = getBrowser();*/
	?>
	<?php //if($ua['name'] == 'Apple Safari') { ?>
	   <link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/customer/assets/css/safari-browser.css">
	<?php //} ?>

 <link rel="stylesheet" type="text/css" href="{{ url() }}/public/front/home/assets/js/datetimepicker/responsive.css"></head>
  <body class="vertical-layout vertical-compact-menu 2-columns   menu-expanded fixed-navbar" data-open="click" data-menu="vertical-compact-menu" data-col="2-columns">
     
@include('customer.include.inner.sidebar')
