
    <!-- BEGIN VENDOR JS-->
    <script src="{{ url() }}/public/front/customer/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="{{ url() }}/public/front/customer/app-assets/vendors/js/forms/icheck/icheck.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN MODERN JS-->
    <script src="{{ url() }}/public/front/customer/app-assets/js/core/app-menu.js" type="text/javascript"></script>
    <script src="{{ url() }}/public/front/customer/app-assets/js/core/app.js" type="text/javascript"></script>
    <!-- END MODERN JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="{{ url() }}/public/front/customer/app-assets/js/scripts/forms/form-login-register.js" type="text/javascript"></script>
	<script src="{{ url() }}/public/front/home/theme-assets/vendors/particles.min.js"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN THEME JS-->
	<script src="{{ url() }}/public/front/home/theme-assets/js/scripts/particles-type1.js"></script>
    <!-- END PAGE LEVEL JS-->
  </body>
</html>

