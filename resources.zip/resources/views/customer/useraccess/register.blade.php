@include('customer.include.master.header')
<link rel="stylesheet" type="text/css" href="{{ url() }}/assets/catalog/javascript/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="{{ url() }}/assets/catalog/javascript/font-awesome/css/font-awesome.min.css">
<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
      </div>
      <div class="content-body">
         <section class="flexbox-container account-content" id="account-login">
            <div id="particles-js"></div>
            <div class="login-content container-fluid">
               <div class="col-12 d-flex align-items-center justify-content-center">
                  <!-- image -->
                  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 col-12 p-0 text-center d-none d-md-block">
                     <div class="border-grey border-lighten-3 m-0 box-shadow-0 height-500 aligner-item">
                        <img src="{{ url() }}/public/front/customer/app-assets/images/pages/account-login-new.png" class="card-account-img img-responsive" alt="card-account-img">
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 col-12 p-0">
                     <div class="card border-grey border-lighten-3 m-0 box-shadow-0 card-account-right height-auto register-height">
                        <div class="card-content">
                           <div class="card-body p-3 account-bg-gradient">
                              <p class="text-center h5 text-capitalize account-head">Welcome To</p>
                              <p class="text-center account-logo"><a href="{{ url() }}"><img src="{{ url() }}/public/front/home/theme-assets/images/account-logo.png" alt="Rewards2pay" class="img-responsive imglogo1" /></a></p>
                              <p class="mb-3 text-center account-subtitle"> Sign Up  Details</p>
                              <form class="form-horizontal form-signin" action="{{ url('sign-up') }}" method="post" name="registerfrm" id="registerfrm">
                                 <div class="row">
                                 <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name *"  value="<?php echo $firstname;?>" required/>
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name *"  value="<?php echo $lastname;?>" required/>
                                    </fieldset>
                                 </div>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <span class="tool-info" data-toggle="tooltip" title="Minimum 7 char required. You can use letters (a-z) and numbers (0-9).">
                                       <input type="text" class="form-control" id="username" name="username" placeholder="User Name *"  value="<?php echo $username;?>" /></span>
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="email" name="email" placeholder="Email *"  value="<?php echo $email;?>" />
                                    </fieldset>
                                 </div>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <span class="tool-info" data-toggle="tooltip" title="Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.">
                                       <input type="password" class="form-control" id="password" name="password" placeholder="Password *"  value="" pattern="(?=.*\d)(?=.*[a-z])(?=.*[@#$%])(?=.*[A-Z]).{8,}" title="Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character." />
                                       </span>
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <span class="tool-info" data-toggle="tooltip" title="Your password and confirm password must match.">
                                       <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Confirm Password *"  />
                                       </span>
                                    </fieldset>
                                 </div>
                                 <fieldset class="form-group ">
                                    <input type="text" class="form-control" id="address" name="address" placeholder="Address *"  value="<?php echo $address;?>" />
                                 </fieldset>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="city" name="city"  placeholder="City *"  value="<?php echo $city;?>" />
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <select name="province" id="province" class="form-control">
                                          <?php if($province==''){ ?> 
                                          <option value="">- Province - </option>
                                          <?php } ?>
                                          <option value="Alberta" <?php if($province=='Alberta'){ echo 'selected=selected';}?>>Alberta</option>
                                          <option value="British Columbia" <?php if($province=='British Columbia'){ echo 'selected=selected';}?>>British Columbia</option>
                                          <option value="Manitoba" <?php if($province=='Manitoba'){ echo 'selected=selected';}?>>Manitoba</option>
                                          <option value="New Brunswick" <?php if($province=='New Brunswick'){ echo 'selected=selected';}?>>New Brunswick</option>
                                          <option value="Newfoundland and Labrador" <?php if($province=='Newfoundland and Labrador'){ echo 'selected=selected';}?>>Newfoundland and Labrador</option>
                                          <option value="Northwest Territories" <?php if($province=='Northwest Territories'){ echo 'selected=selected';}?>>Northwest Territories</option>
                                          <option value="Nova Scotia" <?php if($province=='Nova Scotia'){ echo 'selected=selected';}?>>Nova Scotia</option>
                                          <option value="Nunavut" <?php if($province=='Nunavut'){ echo 'selected=selected';}?>>Nunavut</option>
                                          <option value="Ontario" <?php if($province=='Ontario'){ echo 'selected=selected';}?>>Ontario</option>
                                          <option value="Prince Edward Island" <?php if($province=='Prince Edward Island'){ echo 'selected=selected';}?>>Prince Edward Island</option>
                                          <option value="Québec" <?php if($province=='Québec'){ echo 'selected=selected';}?>>Québec</option>
                                          <option value="Saskatchewan" <?php if($province=='Saskatchewan'){ echo 'selected=selected';}?>>Saskatchewan</option>
                                          <option value="Yukon Territory" <?php if($province=='Yukon Territory'){ echo 'selected=selected';}?>>Yukon Territory</option>
                                       </select>
                                    </fieldset>
                                 </div>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="zipcode" name="zipcode" placeholder="Postal Code *"  value="<?php echo $zipcode;?>" maxlength="7" />
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="country" name="country"  placeholder="Country *"  value="CA" readonly />
                                    </fieldset>
                                 </div>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="phone" name="phone" maxlength="12" placeholder="Phone *" onkeypress="return ValidatePhoneNo()" value="<?php echo $phone;?>" />
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <div class="input-group " id="date" >
                                          <input type="text"  placeholder="DoB *" id="dob" name="dob" data-date-format="DD/MM/YYYY" class="form-control" readonly value="<?php echo $dob;?>" />
                                          <span class="input-group-btn topcls">
                                          <button class="btn btn-default" type="button"><i class="fa fa-calendar"></i></button>
                                          </span>
                                       </div>
                                    </fieldset>
                                 </div>
                                 <button type="submit" id="btn-submit" class="btn-gradient-primary account-gradiant-btn btn-block my-1" >Sign Up <span id="loadingImg" style="display:none"><img src="{{ url() }}/public/front/loader/spin.gif"></span></button>
                                 <p class="text-center">
                                    <a href="{{ url() }}" class="card-link white-link"><i class="fa fa-arrow-circle-left"></i> Back</a>
                                    <a href="{{ url('sign-in') }}" class="card-link white-link">Sign In</a>
                                 </p>
                              </form>
                               <script src="{{ url() }}/public/front/home/assets/js/datetimepicker/jquery.validate.min.js"></script>
                              <script>
                                 //form validation rules
                                 $("#registerfrm").validate({
                                 rules: {
                                  username: {
                                               minlength : 7,
                                               required: true
                                       },
                                  password : {
                                               minlength : 8,
                                               required: true
                                       },
                                  cpassword : {
                                               minlength : 8,
                                               required: true,
                                               equalTo: "#password"
                                       },
                                       country:"required",
                                       province:"required",
                                  firstname: "required",
                                  lastname: "required",
                                  address: "required",
                                  phone: {
									    minlength : 10,
                                               required: true
									  },
                                  email: "required",
                                  zipcode: "required",
                                  dob: "required",
                                  city: "required",
                                 }
                                 ,
                                 messages: {
                                   username:{
                                               minlength : "",
                                                required: " "
                                       },
                                   password : {
                                               minlength : "",
                                                required: " "
                                       },
                                   cpassword : {
                                           minlength : "",
                                           required: " ",
                                           equalTo : ""
                                   },
                                    phone : {
                                               minlength : "",
                                                required: " "
                                       },
                                   country:"",
                                   province:"",
                                  firstname: " ",
                                  lastname: "",
                                  address: "",
                                  email: "",
                                  zipcode: "",							  
                                  dob: "",	
                                  city: "",
                                 }
                                 ,
                                 submitHandler: function(form) {
                                 $("#num").hide();
                                  form.submit();
                                 $("#loadingImg").show();
                                   $(this).find("#btn-submit").prop('disabled', true);
                                 }
                                 }
                                 );
                              </script>
                              
                              <?php if(!empty($error)){?>
                              <div class="alert alert-danger  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $error;?>
                              </div>
                              <?php  } ?>
                              <?php if(!empty($success)){?>
                              <div class="alert alert-success  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $success;?>
                              </div>
                              <?php } ?>
                             <!-- <?php //$successflash = $this->session->flashdata('success');
                                 //$errorflash = $this->session->flashdata('error');
                                 
                                 //if($errorflash!=''){ ?>
                              <div class="alert alert-danger  alert-dismissible msg">
                                 <a onclick="sessiondestroe()" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  //echo $errorflash;?>
                              </div>
                              <?php //} if(!empty($successflash)){?>
                              <div class="alert alert-success  alert-dismissible msg">
                                 <a onclick="sessiondestroe()" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  //echo $successflash;?>
                              </div>
                              <?php //} ?>-->
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   </div>
</div><script>
           // var today='18/07/2018';
               $('#date').datetimepicker({
                 format: 'dd/mm/yyyy',
               endDate: new Date(), 
               maxDate: new Date() 
                });	 
         </script>
<script>
   function sessiondestroe()
   {
   var v='	<?php 
     // $this->session->set_flashdata('success', '');
    //  $this->session->set_flashdata('error', '');
      ?>';
   }
</script>

<style>
@media only screen and (min-width:320px) and (max-width:560px){

	.card.border-grey.border-lighten-3.m-0.box-shadow-0.card-account-right.height-auto.register-height {
    height: 300px ;
	}
}
</style>

@include('customer.include.master.footer')
