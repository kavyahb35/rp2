@include('customer.include.master.header')
<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
      </div>
      <div class="content-body">
         <section class="flexbox-container account-content" id="account-login">
            <div id="particles-js"></div>
            <div class="login-content container-fluid">
               <div class="col-12 d-flex align-items-center justify-content-center">
                  <!-- image -->
                  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 col-12 p-0 text-center d-none d-md-block">
                     <div class="border-grey border-lighten-3 m-0 box-shadow-0 height-500 aligner-item">
                        <img src="{{ url() }}/public/front/customer/app-assets/images/pages/account-login-new.png" class="card-account-img img-responsive" alt="card-account-img">
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 col-12 p-0">
                     <div class="card border-grey border-lighten-3 m-0 box-shadow-0 card-account-right height-500">
                        <div class="card-content">
                           <div class="card-body p-3 account-bg-gradient">
                              <p class="text-center h5 text-capitalize account-head">Welcome To</p>
                              <p class="text-center account-logo"><a href="{{ url() }}"><img src="{{ url() }}/public/front/home/theme-assets/images/account-logo.png" alt="Rewards2pay" class="img-responsive imglogo1" /></a></p>
                              <p class="mb-3 text-center account-subtitle"> Login Details</p>
                              <form class="form-horizontal form-signin" action="<?php //echo base_url('sign-in'); ?>" method="post" name="loginfrm" id="loginfrm">
                                 <fieldset class="form-group" action="<?php //echo base_url('sign-in');?>" method="post">
                                 <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter User Name" value="<?php //echo $_COOKIE['remember_meusername']; ?>"  />
                                 </fieldset>
                                 <fieldset class="form-group">
                                    <input type="password" class="form-control"id="password" name="password"  placeholder="Enter Password" value="<?php //echo $_COOKIE['remember_mepassword']; ?>" />
                                 </fieldset>
                                 
                                   <div class="form-group row">
                               <!-- <div class="col-md-6 col-12 text-center text-sm-left">
                                    <fieldset>
                                        <input type="checkbox" id="remember-me" class="chk-remember" name="remember" value="1">
                                        <label for="remember-me" style="color:#fff"> Remember</label>
                                    </fieldset>
                                </div>-->
                                <div class="col-md-12 col-12 float-sm-left text-center text-sm-right"><a href="{{ url('forgot-password') }}" class="card-link white-link">Forgot Password?</a></div>
                            </div>
                                 <!--<a href="<?php //echo base_url('dashboard');?>" class="btn-gradient-primary btn-block my-1">Log In</a>-->
                                 <button type="submit" class="btn-gradient-primary account-gradiant-btn btn-block my-1" id="btn-submit">Log In <span id="loadingImg" style="display:none"><img src="{{ url() }}/public/front/loader/spin.gif"></span></button>
                                 <p class="text-center">
                                    <a href="{{ url('/sign-in') }}" class="card-link white-link"><i class="fa fa-arrow-circle-left"></i> Back</a>
                                    <a href="{{ url('/sign-up') }}" class="card-link white-link">Register</a>
                                 </p>
                              </form>
                               <script src="{{ url() }}/public/front/home/assets/js/datetimepicker/jquery.validate.min.js"></script>
                              <script>
                                 //form validation rules
                                 $("#loginfrm").validate({
                                 rules: {
                                  username: "required",
                                  password: "required",
                                 }
                                 ,
                                 messages: {
                                  username: " ",
                                  password: "",
                                 }
                                 ,
                                 submitHandler: function(form) {
                                 $("#num").hide();
                                  form.submit();
                                 $("#loadingImg").show();
                                   $(this).find("#btn-submit").prop('disabled', true);
                                 }
                                 }
                                 					 );
                              </script>
                              
                              <?php if(!empty($error)){?>
                              <div class="alert alert-danger  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $error;?>
                              </div>
                              <?php  } ?>
                              <?php if(!empty($success)){?>
                              <div class="alert alert-success  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $success;?>
                              </div>
                              <?php } ?>
                             <!-- <?php //$successflash = $this->session->flashdata('success');
                                 //$errorflash = $this->session->flashdata('error');
                                 
                                 //if($errorflash!=''){ ?>
                              <div class="alert alert-danger  alert-dismissible msg">
                                 <a onclick="sessiondestroe()" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  //echo $errorflash;?>
                              </div>
                              <?php //} if(!empty($successflash)){?>
                              <div class="alert alert-success  alert-dismissible msg">
                                 <a onclick="sessiondestroe()" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  //echo $successflash;?>
                              </div>
                              <?php //} ?>-->
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   </div>
</div>
<script>
   function sessiondestroe()
   {
   var v='	<?php 
     // $this->session->set_flashdata('success', '');
    //  $this->session->set_flashdata('error', '');
      ?>';
   }
</script>

@include('customer.include.master.footer')
