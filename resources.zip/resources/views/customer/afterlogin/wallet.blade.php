@include('customer.include.inner.header')
<link rel="stylesheet" type="text/css" href="{{ url('/public/front/customer') }}/app-assets/css/pages/transactions.css">
<div class="app-content content wallet-layout">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
                <h3 class="content-header-title mb-0 d-inline-block">Wallet</h3>
            </div>
            <div class="content-header-right col-md-4 col-12 d-md-inline-block btn-add-prog">
                    <div class="btn-group float-md-right"><a class="btn-gradient-secondary btn-gradient-redyellow btn-sm white pull-right" href="{{ url ('/manage-cards') }}">Add Loyalty Program</a></div>
            </div>
        </div>
		
        <div class="content-detached">
            <div class="content-body">
                <div id="wallet">
                    <div class="wallet-table-th d-none d-md-block">
                        <div class="row">
                            <div class="col-md-5 col-12 py-1">
                                <p class="mt-0 text-capitalize list-head">Loyalty Cards</p>
                            </div>
                            <div class="col-md-3 col-12 py-1 text-center">
                                <p class="mt-0 text-capitalize list-head">Available Points</p>
                            </div>
                            <div class="col-md-2 col-12 py-1 text-center">
                                <p class="mt-0 text-capitalize list-head">Est. Cash Value</p>
                            </div>
                            <div class="col-md-2 col-12 py-1 text-center"></div>
                        </div>
                    </div>
                     <?php if(!empty($success)){
                        foreach($success as $response){ 
                            
                            $imgs = $response['progId'];
                            $img = $imgs.'.png';
                            
                                
                                   if($imgs!=''){ 
			if (file_exists(public_path() . '/front/customer/app-assets/images/cards/75/' . $img)){  
				$image = $img;  
			} else {  
				$image = 'dummy.png'; 
				}
			 } else{
				$image = 'dummy.png';
		}
                            ?>
                    <!-- BTC -->
                    <section class="card pull-up wallet-list">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-5 col-12 py-1">
                                            <div class="media">
                                                <a onclick="removepoints('<?php echo $response['progId'];?>','<?php echo $response['programName'];?>')" ><i class="fa fa-trash"></i></a>
                                                <img src="{{ url('/') }}/public/front/customer/app-assets/images/cards/75/<?php echo $image;?>" />
                                                <div class="media-body">
                                                    <h5 class="mt-0 text-capitalize wallet-card-name"><?php echo $response['programName'];?></h5>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-3 col-12 py-1 text-center">
                                            <h6 class="wallet-point"><?php echo $response['pointBalance'];?> <small>Points</small></h6>
                                            <p class="text-muted mb-0 font-small-3 wallet-update">Updated: <?php 

$timestem = $response['lastUpdated'];
                                           ?></p>
                                            <span class="wallet-refresh"><a onclick="refreshpoints('<?php echo $response['progId'];?>','<?php echo $response['programName'];?>')" ><i class="fa fa-refresh"></i></a></span>  </div>
                                        <div class="col-sm-12 col-md-2 col-12 py-1 text-center">
                                            <h6 class="wallet-cash"><?php echo $response['cashBalance'];?> <small>CAD</small></h6>
                                        </div>
                                        <div class="col-sm-12 col-md-2 col-12 py-1 text-center">
                                            <?php if($response['canRedeem']=='Y'){ ?>
                                            <button class="btn-gradient-reedem btn-sm white line-height-3" data-toggle="modal" data-target="#purchaseBTCModalLabel-<?php echo $response['progId'];?>">Redeem</button>
                                            <?php }?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    
                    <div class="modal fade reedem-popup" id="purchaseBTCModalLabel-<?php echo $response['progId'];?>" tabindex="-1" role="dialog" aria-labelledby="purchaseBTCModalLabel-<?php echo $response['progId'];?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="purchaseModalLabel">Reedem Your Loyalty Points</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-md-2 col-12 d-none d-md-block">
                                                   <img class="card-img-top img-responsive" src="{{ url('/') }}/public/front/customer/app-assets/images/cards/75/<?php echo $image;?>" alt="<?php echo $response['programName'];?>" width="200" />
                                                </div>
                                                <div class="col-md-6 col-12">
                                                    <p><strong class="card-name"><?php echo $response['programName'];?></strong></p>
                                                </div>
                                                <div class="col-md-4 col-12 d-none d-md-block text-center">
                                                    <h6 class="card-point"><?php echo $response['pointBalance'];?> <span>Points</span></h6>
                                                                                        <p class="text-muted mb-0 font-small-3 card-update">Updated: <?php $timestem =  $response['lastUpdated'];
                                          ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                <?php if(($response['minimumBalance']==$response['pointBalance']) || ($response['pointBalance'] > $response['minimumBalance'])){ ?>
                                <form class="form form-horizontal mt-2 mx-2" novalidate id="form-card-<?php echo $response['progId'];?>" method="post" novalidate>
                                    <div class="form-body">
                                        <div class="row">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                            <input type="hidden" name="programid"  value="<?php echo $response['progId'];?>">
                                            <input type="hidden" name="programidname"  value="<?php echo $response['programName'];?>">
                                            <input type="hidden" name="minimumBalance"  value="<?php echo $response['minimumBalance'];?>">
                                             <input type="hidden" name="pointBalance"  value="<?php echo $response['pointBalance'];?>">
											<div class="col-sm-12 col-md-5 col-lg-5">
												<p class="reedem-point-title ht-100 text-center">Max. points you wish to redeem?</p>
												<div class="input-group">
                                                                                                    <input type="text" class="form-control" aria-describedby="basic-addon4" name="redeemvalue" id="redeemvalue-<?php echo $response['progId'];?>" onkeypress="return ValidatePhoneNo()" oninput="clearmsg('<?php echo $response['progId'];?>')">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon4"><i class="fa fa-trophy"></i></span>
                                                    </div>
												</div>
												<p class="mb-0 text-center font-medium-5 mt-20">
													<a class="btn-gradient-secondary btn-gradient-redyellow-reedem btn-sm white" onclick="redeemvaluefuncion('<?php echo $response['progId']; ?>')">Go</a>
											    </p>
											</div>
											<div class="col-sm-12 col-md-2 col-lg-2 exchange-div">
												<p class="mb-0 text-center font-medium-5 exchange"><i class="fa fa-exchange"></i></p>
											</div>
											<div class="col-sm-12 col-md-5 col-lg-5">
												<p class="reedem-point-title ht-100 text-center">Cash Value?</p>
												<div class="input-group">
													<input type="text" class="form-control" name="cashvalue" id="cashvalue-<?php echo $response['progId'];?>" aria-describedby="basic-addon4" onkeypress="return ValidatePhoneNo()"  oninput="clearmsg1('<?php echo $response['progId'];?>')">
													<div class="input-group-append">
													  <span class="input-group-text" id="basic-addon4"><i class="fa fa-usd"></i></span>
													</div>
												</div>
												<p class="mb-0 text-center font-medium-5 mt-20">
													<a class="btn-gradient-secondary btn-gradient-redyellow-reedem btn-sm white" onclick="cashvaluefuncion('<?php echo $response['progId']; ?>')">Go</a>
												</p>
											</div>
										</div>
										<div class="row last-rows">
											<div class="col-sm-12">
												<div class="text-center" id="confirmsucc<?php echo $response['progId'];?>" style="display:none">
													<a class="btn-gradient-secondary btn-sm white" href="">Confirm</a>
												</div>
											</div>
										</div>
                                       <div class="row last-rows">
											<div class="col-sm-12">
												<div class="text-center">
                                                                                                    <div class="successredeem" id="successredeem"></div>
                                                                                                    <div class="errorredeem" id="errorredeem"></div>
												</div>
											</div>
										</div>
									</div>
								</form>
                                <?php }else {
                                    echo '<div class="mincls">You don`t have sufficient balance points to redeem. you need at least '.$response['minimumBalance'].' points </div>';
                                } ?>
                            </div>
                        </div>
                    </div>
                </div>
                      <?php }
                     }else{ ?>  
                    <section class="card pull-up wallet-list">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="col-12">
                                    <div class="row">
                                        
                                        Program not found!
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                     <?php } ?>
                  
                </div>
            </div>
        </div>
          <script type="text/javascript">
			var jq = $.noConflict();
           function refreshpoints(id,fname)
           {
               var url ="wallet/refreshpoins";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: {
					"_token": "{{ csrf_token() }}",
					"programid": id
					},
                success: function (data) {
                  if(data.succ=='1'){
					  jq.dialog({
					    title: 'Success!',
					    content: 'Your '+fname+' card point has been successfully updated.',
					    onClose: function () {
							location.reload();
						},
					 });
                  }
                }
              });
           }
           function removepoints(id,fname)
           {
               var url ="wallet/removepoins";
               var cnf = confirm("Are You sure want to Delete this program?");
               if (cnf=true) {
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                 data: {
					"_token": "{{ csrf_token() }}",
					"programid": id
					},
                success: function (data) {
                  if(data.succ=='1'){
                      jq.dialog({
					    title: 'Success!',
					    content: data.success,
					    onClose: function () {
							location.reload();
						},
					 });
					  // alert(data.success);location.reload();
                  }
                  if(data.err == '2'){
                      jq.dialog({
					    title: 'Warning!',
					    content: data.error,
					    onClose: function () {
							location.reload();
						},
					 });
					// alert(data.error);location.reload();
                  }
                }
              });
           } 
        }
        
        function redeemvaluefuncion(id)
        {
              var url ="wallet/redeemvaluefuncion";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: $("#form-card-"+id).serialize(),
                success: function (data) {
                  if(data.succ=='1'){
                      $('#redeemvalue-'+id).val(data.pointBalance1);
                      $('#cashvalue-'+id).val(data.cashBalance);
                      // document.getElementById('redeemvalue-'+id).value = data.pointBalance1;
                       // document.getElementById('cashvalue-'+id).value = data.cashBalance;
                        $("#confirmsucc"+id).show();
                        $('.successredeem').html(data.success).delay(2000).fadeOut();
					  // alert(data.success);location.reload();
                  }
                  if(data.err == '2'){
                       $("#confirmsucc"+id).hide();
                     $('.errorredeem').html(data.error).delay(2000).fadeOut();
					// alert(data.error);location.reload();
                  }
                }
              });
            
        }
        function cashvaluefuncion(id)
        {
             var url ="wallet/cashvaluefuncion";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: $("#form-card-"+id).serialize(),
                success: function (data) {
                  if(data.succ=='1'){
                       $('#redeemvalue-'+id).val(data.pointBalance1);
                      $('#cashvalue-'+id).val(data.cashBalance);
                        //document.getElementById('redeemvalue-'+id).value = data.pointBalance1;
                       // document.getElementById('cashvalue-'+id).value = data.cashBalance;
                        $("#confirmsucc"+id).show();
                        $('.successredeem').html(data.success).delay(2000).fadeOut();
					  // alert(data.success);location.reload();
                  }
                  if(data.err == '2'){
                       $("#confirmsucc"+id).hide();
                     $('.errorredeem').html(data.error).delay(2000).fadeOut();
					// alert(data.error);location.reload();
                  }
                }
              });
        }
        
        function clearmsg(id){
           $('#cashvalue-'+id).val('');
          // document.getElementById('cashvalue-'+id).value = '';
        }
         function clearmsg1(id){
              $('#redeemvalue-'+id).val('');
          // document.getElementById('redeemvalue-'+id).value = '';
        }
        </script>
        <script>
	function ValidatePhoneNo() {
		if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
			return event.returnValue;
			return event.returnValue = '';
	}
</script> 
        <style>
        .errorredeem {
    color: #f15;
    font-weight: 700;
    font-size: 16px;
    }.successredeem {
        color: green;
       font-weight: 700;
        font-size: 16px;
    }
        </style>
    </div>
</div>

  
@include('customer.include.inner.footer')
