@include('customer.include.inner.header')
<div class="app-content content dashboard-layout">
      <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
                <h3 class="content-header-title mb-0 d-inline-block">Dashboard</h3>
            </div>
            <div class="content-header-right col-md-4 col-12 d-md-inline-block btn-add-prog">
                <div class="btn-group float-md-right"><a class="btn-gradient-secondary btn-gradient-redyellow btn-sm white pull-right" href="{{ url('/manage-cards') }}">Add Loyalty Program</a></div>
            </div>
        </div>
        <div class="content-body">
        <div class="row">
    <div class="col-md-12 col-12">
        <h6 class="my-2">Your Balance</h6>
        <div class="card pull-up">
            <div class="card-content">
                <div class="card-body">
					<div class="row dash-points">
						<?php if(!empty($success)) {    
                              $points = 0;
                              $pointsbalance1s = 0;
                          foreach($success as $response) {
                              $point = $response['pointBalance'];
                              $pointsbalance1 = $response['cashBalance'];
                              $points = $point + $points;
                              $pointsbalance1s = $pointsbalance1 + $pointsbalance1s;
                            }
                          } ?>
						<div class="col-sm-12 col-md-3">
							<p class="est-cash-title"><strong>Estimated Cash Balance <span>?</span></strong></p>
							<h1 class="est-cash"><?php if($points!=''){ echo $points; }else { echo '0';}?> <span>CAD</span></h1>
						</div>
						<div class="col-sm-12 col-md-3 btn-redeem">
							<a href="{{ url('/wallet') }}"><button class="btn-gradient-reedem btn-sm white line-height-3">Redeem</button></a>
						</div>
						<div class="col-sm-12 col-md-3">
							<p class="est-cash-title"><strong>Rewards2Pay Wallet Balance</strong></p>
							<h1 class="est-cash"><?php if($pointsbalance1s!=''){ echo $pointsbalance1s; }else { echo '0';}?> <span>CAD</span></h1>
						</div>
						<div class="col-sm-12 col-md-3 btn-dash-payout">
						<!---- paypal code starting ---------------------------------------------->
					  
						<form action="{{ url('/buy') }}" method="post">
								<input type="hidden" name="business" value="sumit@cueserve.com"> 
								<input type="hidden" name="cmd" value="_xclick"> 
								 <input type="hidden" name="item_name" value="Rewards2Pay"> 
								<input type="hidden" name="item_number" value="1">
								<input type="hidden" name="amount" value="<?php echo $pointsbalance1s;?>">   
								<input type="hidden" name="currency_code" value="CAD">   
								 <input type="hidden" name="_token" value="{{ csrf_token() }}">
								<input type="hidden" name="cancel_return" value="{{ url() }}/cancel"> 
								<input type="hidden" name="return" value="{{ url() }}//success">
								<input type="hidden" name="notify_url" value="{{ url() }}//ipn">
								
							<button type="submit" class="btn-gradient-secondary mt-2">Payout <i class="la la-angle-right"></i></button>
						</form>
					   
						
						<!---- ended code --------------------------------------------------------->
					</div>
					</div>
				
                </div>
            </div>
        </div>
    </div>
</div>
<!--/ ICO Token balance & sale progress -->
<div class="dashboard-card">
	<div class="row dash-prog-title">
		<div class="col-md-12 col-12"><h6 class="my-2">Your Loyalty Program</h6></div>
	</div>
	<div class="row rowsafari">
	<?php if(!empty($success)) { ?>
		<?php foreach($success as $response) { ?>
			<?php $imgs = $response['progId']; ?>
			<?php $img = $imgs.'.png'; ?>
			<?php 
			
		if($imgs!=''){ 
			if (file_exists(public_path() . '/front/customer/app-assets/images/cards/150/' . $img)){  
				$image = $img;  
			} else {  
				$image = 'dummy.png'; 
				}
			 } else{
				$image = 'dummy.png';
		} ?>
			<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-2">
                              <div class="pull-up">
				<div class="card ">
					<div class="card-img text-center">
						<img class="img-responsive" src="{{ url('/') }}/public/front/customer/app-assets/images/cards/150/<?php echo $image;?>" alt="Aeroplane">
					</div>
					<div class="card-body text-center">
						<h5 class="card-title"><?php echo $response['programName'];?></h5>
					</div>
					<div class="card-img text-center card-barcode">
						<?php if($response['canBarcodeStandard']!=''){ ?>
							<?php if($response['canBarcodeStandard']=='code_128'){ ?>
								<img class="img-responsive" src="barcode.php?f=png&s=code-128&d=<?php echo $response['cardNumber']; ?>&ABCD">
						  <?php } else { ?>
							   <img class="img-responsive" src="barcode.php?f=png&s=ean-13&d=<?php echo $response['cardNumber']; ?>&*">
						  <?php } ?>
						<?php } ?>
					</div>        
					
				</div>
                             </div>
			</div>
		<?php } ?>
	<?php }else {?>
            <div class="card pull-up" style=" width: 97%;  margin-left: 16px;">
            <div class="card-content">
                <div class="card-body">
                    <div class="col-12">
                        <div class="row">
                          
                            <div class="col-md-12 col-12">
                                <p class="est-cash-title"><strong>Program not found!</strong></p>
                                 </div>
							
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
	</div>
</div>
  
<!-- ICO Token balance & sale progress -->
      </div>
    </div>
  
@include('customer.include.inner.footer')
