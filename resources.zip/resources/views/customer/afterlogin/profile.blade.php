@include('customer.include.inner.header')

<link rel="stylesheet" type="text/css" href="{{ url() }}/assets/catalog/javascript/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="{{ url() }}/assets/catalog/javascript/font-awesome/css/font-awesome.min.css">

<script src="{{ url() }}/public/front/home/assets/js/datetimepicker/moment.js"></script>
<link rel="stylesheet" href="{{ url() }}/public/front/home/assets/js/datetimepicker/bootstrap-datetimepicker.min.css">
<script src="{{ url() }}/public/front/home/assets/js/datetimepicker/bootstrap-datetimepicker.min.js"></script>
<script src="{{ url() }}/public/front/home/assets/js/datetimepicker/bootstrap.min.js"></script>

<div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block"> Profile</h3>
            <div class="row breadcrumbs-top d-inline-block">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="{{ url('/dashboard')}}">Dashboard</a>
                  </li>
                  
                </ol>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body"><div class="row">
			<div class="col-12 col-md-12">
				<!-- User Profile -->
				<section class="card">
					<div class="card-content">
						<div class="card-body">
							<div class="col-12">
								<div class="row">
									<div class="col-md-12 col-12">
										<div class="row">
											<div class="col-12 col-md-4">
												<p class="text-bold-700 text-uppercase mb-0">Transactions</p>
												<p class="mb-0"><?php echo session()->get('lastUpdate');?></p>
											</div>
											<div class="col-12 col-md-4">
												<p class="text-bold-700 text-uppercase mb-0">Last login</p>
												<p class="mb-0"><?php echo session()->get('lastUpdate');?></p>
											</div>
											
										</div>
										<hr/>
								<?php if(!empty($error)){?>
								   <div class="alert alert-danger  alert-dismissible msg">
									  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
									  </a>
									  <?php  echo $error;?>
								   </div>
								   <?php } ?>
								   <?php if(!empty($success)){?>
								   <div class="alert alert-success  alert-dismissible msg">
									  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
									  </a>
									  <?php  echo $success;?>
								   </div>
								   <?php } ?>
										<form class="form-horizontal form-user-profile row mt-2" action=" {{ url('/update-profile') }}" method="post" name="registerfrms" id="registerfrms">
										<input type="hidden" name="_token" value="{{ csrf_token() }}">
											<div class="col-6">
												<fieldset class="form-label-group">
													<input type="text" name="firstname" class="form-control" id="firstname" value="<?php echo session()->get('cfirstName');?>" readonly>
													
												</fieldset>
											</div>
											<div class="col-6">
												<fieldset class="form-label-group">
													<input type="text" name="lastname" class="form-control" id="lastname" value="<?php echo session()->get('clastName');?>" readonly>
													
												</fieldset>
											</div>
											
											<div class="col-6">
												<fieldset class="form-label-group">
													<input type="text" class="form-control" id="email" name="email" value="<?php echo session()->get('cuserEmail');?>" placeholder="Enter Email Id" readonly>
												   
												</fieldset>
											</div>
											<div class="col-6">
												<fieldset class="form-label-group">
													<input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone" value="<?php echo session()->get('cphone');?>"  placeholder="Enter Phone" onkeypress="return ValidatePhoneNo()" maxlength="12">
													
												</fieldset>
											</div>
											<!------------------------------------------------------------------>
											
											
											<div class="col-12">
                                                                                            <?php   $fulladdress = session()->get('caddress');
                                                                                            if($fulladdress!='') {
                                                                                                   $all=  explode('|', $fulladdress);
                                                                                                   $address = $all[0];
                                                                                                   $count = substr_count($fulladdress, "|");
                                                                                                   if($count > 0 && $count=='1'){
																									    $city = $all[1];
																									}
																									if($count=='2'){
																										$city = $all[1];
																										$province = trim($all[2]);
																									}
																									if($count=='3'){
																										$city = $all[1];
																										$province = trim($all[2]);
																										$zipcode = $all[3];
																									}
																									if($count=='4'){																			
																										$city = $all[1];
																										$province = trim($all[2]);
																										$zipcode = $all[3];
																										$country = $all[4];
																									}
                                                                                                  
																							   }
                                                                                            ?>
												<fieldset class="form-label-group">
													<input type="text" class="form-control" id="address" name="address" value="<?php echo $address;?>"  placeholder="Enter Address" />
												   
												</fieldset>
											</div>
											
                                                                                    <div class="col-6">
												<fieldset class="form-label-group">
													<input type="text" class="form-control" id="city" placeholder="Enter city" name="city" placeholder="City " value="<?php echo $city;?>"   /> 												   
												</fieldset>
											</div>
                                                                                    <div class="col-6">
												<select name="province" id="province" class="form-control">
                                                                                                    <?php if($province==''){ ?> 
                                                                                                    <option value="">- Province - </option>
                                                                                                    <?php } ?>
                                                                                                    <option value="Alberta" <?php if($province=='Alberta'){ echo 'selected=selected';}?>>Alberta</option>
                                                                                                    <option value="British Columbia" <?php if($province=='British Columbia'){ echo 'selected=selected';}?>>British Columbia</option>
                                                                                                    <option value="Manitoba" <?php if($province=='Manitoba'){ echo 'selected=selected';}?>>Manitoba</option>
                                                                                                    <option value="New Brunswick" <?php if($province=='New Brunswick'){ echo 'selected=selected';}?>>New Brunswick</option>
                                                                                                    <option value="Newfoundland and Labrador" <?php if($province=='Newfoundland and Labrador'){ echo 'selected=selected';}?>>Newfoundland and Labrador</option>
                                                                                                    <option value="Northwest Territories" <?php if($province=='Northwest Territories'){ echo 'selected=selected';}?>>Northwest Territories</option>
                                                                                                    <option value="Nova Scotia" <?php if($province=='Nova Scotia'){ echo 'selected=selected';}?>>Nova Scotia</option>
                                                                                                    <option value="Nunavut" <?php if($province=='Nunavut'){ echo 'selected=selected';}?>>Nunavut</option>
                                                                                                    <option value="Ontario" <?php if($province=='Ontario'){ echo 'selected=selected';}?>>Ontario</option>
                                                                                                    <option value="Prince Edward Island" <?php if($province=='Prince Edward Island'){ echo 'selected=selected';}?>>Prince Edward Island</option>
                                                                                                    <option value="Québec" <?php if($province=='Québec'){ echo 'selected=selected';}?>>Québec</option>
                                                                                                    <option value="Saskatchewan" <?php if($province=='Saskatchewan'){ echo 'selected=selected';}?>>Saskatchewan</option>
                                                                                                    <option value="Yukon Territory" <?php if($province=='Yukon Territory'){ echo 'selected=selected';}?>>Yukon Territory</option>
                                                                                                 </select>
											</div>
                                                                                    <div class="col-6">
												<fieldset class="form-label-group">
													<input type="text" class="form-control" id="zipcode" placeholder="Enter Postcode" name="zipcode" value="<?php echo $zipcode;?>"   maxlength="7" >												   
												</fieldset>
											</div>
                                                    
											<!--------------------------------------------------------------------->
											                                <div class="col-6">
												<fieldset class="form-label-group">
													<input type="text" class="form-control" id="country" name="country"  placeholder="Country *"  value="CA" readonly />
                                                                                                </fieldset>
											</div>
											<div class="col-6">
												<fieldset class="form-label-group">
												   <div class="input-group " id="date">
													<input type="text"  placeholder="DoB" id="dob" name="dob" data-date-format="DD/MM/YYYY" class="form-control" readonly value="<?php echo session()->get('cdob');?>"  placeholder="Enter DoB">
													<span class="input-group-btn topcls">
													<button class="btn btn-default" type="button"><i class="fa fa-calendar"></i></button>
													</span>
												 </div>
												</fieldset>
											</div>
											<div class="col-12 text-right">
												<button type="submit" class="btn-gradient-primary my-1" id="btn-submit" onclick="dem()">Save  <span id="loadingImg" style="display:none"><img src="{{ url() }}/public/front/loader/spin.gif"></span></button>
											</div>
										</form>
									   <script src="{{ url() }}/public/front/home/assets/js/datetimepicker/jquery.validate.min.js"></script>
								   <script>
								   function dem(){
									   
									  //form validation rules
									  $("#registerfrms").validate({
									  rules: {
									   firstname: "required",
									   lastname: "required",
									   address: "required",
                                                                           city: "required",
                                                                           province:"",
									   phone: "required",
									   email: "required",
									  }
									  ,
									  messages: {
									   firstname: "",
									   lastname: "",
									   address: "",
                                                                           city:"",
                                                                           province:"",
									   phone: "",
									   email: "",
									  }
									  ,
									  submitHandler: function(form) {
									  $("#num").hide();
									   form.submit();
										$("#loadingImg").show();
										$(this).find("#btn-submit").prop('disabled', true);
									  }
									  }
														 );
									   }
								   </script>
									   
									   </div>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
			<!--<div class="col-12 col-md-4">
				<div class="card">
					<div class="card-header">
						<h6 class="card-title text-center">Your Balance <span>?</span></h6>
					</div>
					<div class="card-content collapse show">
						<div class="card-body">
							<div class="text-center row clearfix mb-2">
								<div class="col-12">
									<i class="icon-layers font-large-1 bg-grey bg-glow white rounded-circle p-2 d-inline-block"></i>
								</div>
							</div>
							<p class="est-cash-title text-center">Estimated Cash Balance <span>?</span></p>
							<h3 class="text-center est-cash">2400.00 <span>CAD</span></h3>
							<p class="wallet-cash-title text-center">Rewards2Pay Wallet Balance</p>
							<h3 class="text-center wallet-cash">1200.00 <span>CAD</span></h3>
							<div class="payout-btn text-center"><a href="#" class="btn-gradient-secondary btn-gradient-redyellow btn-sm white">Payout</a></div>
						</div>
					</div>
				</div>
			</div>-->
		</div>
	</div>
  </div>
</div>
  
<script>
	$('#date').datetimepicker({
		startDate: '21/05/2011', 
		format: 'dd/mm/yyyy',
		 endDate: new Date(), 
               maxDate: new Date() 
	});	 
</script>
<script>
	function ValidatePhoneNo() {
		if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
			return event.returnValue;
			return event.returnValue = '';
	}
</script> 
