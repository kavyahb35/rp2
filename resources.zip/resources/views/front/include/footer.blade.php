 <footer class="footer static-bottom  footer-custom-class" data-midnight="white"><div class="container">
    <div class="footer-wrapper">
        <div class="row">
            <div class="col-md-4">
                <div class="about">
                    <div class="title animated" data-animation="fadeInUpShorter" data-animation-delay="0.2s">
                       <a href="#head-area"><img src="{{ url() }}/public/front/home/theme-assets/images/logo.png" alt="Logo"></a>

                    </div>
                    <div class="about-text animated" data-animation="fadeInUpShorter" data-animation-delay="0.3s">
                        <p class="grey-accent2">Our aim is to make loyalty points fungible by allowing customers to use points as a payment alternate.</p>
                    </div>
                    <ul class="social-buttons list-unstyled mb-5">
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.4s"><a href="#" title="Facebook" class="btn font-medium"><i class="ti-facebook"></i></a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.5s"><a href="#" title="Twitter" class="btn font-medium"><i class="ti-twitter-alt"></i></a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.6s"><a href="#" title="LinkedIn" class="btn font-medium"><i class="ti-linkedin"></i></a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.7s"><a href="#" title="GitHub" class="btn font-medium"><i class="ti-github"></i></a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.8s"><a href="#" title="Pintrest" class="btn font-medium"><i class="ti-pinterest"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="links">
                    <h5 class="title animated" data-animation="fadeInUpShorter" data-animation-delay="0.5s">Useful Links</h5>
                    <ul class="useful-links  mr-5">
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="1.2s"><a href="<?php //echo base_url();?>">Home</a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="1.3s"><a href="<?php //echo base_url();?>#about">
                        About Us</a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.8s"><a href="#problem-solution">Services </a></li>
                    </ul>
                    <ul class="useful-links">
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.9s"><a href="#team">Our Testimonials</a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="1.0s"><a href="#faq">FAQ</a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="1.0s"><a href="#contact">Contact</a></li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="1.1s"><a href="<?php //echo base_url('sign-in');?>">Sign in</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feed">
                    <h5 class="title animated" data-animation="fadeInUpShorter" data-animation-delay="0.8s">Twitter Feed</h5>
                    <div class="tweets">
                            <!--<span class="animated" data-animation="fadeInUpShorter" data-animation-delay="1.0s">More about our most powerful theme Crypto ICO : https://t.co/JHBAS345</span>
                            <span class="animated" data-animation="fadeInUpShorter" data-animation-delay="1.2s">More infotamation about CIC Coin : https://t.co/JHSD34JHB</span>-->
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right mx-auto text-center">
            <span class="copyright">Copyright &copy; 2018, rewards2pay.com Designed by <a href="" title="pixinvent" class="white">Cueserve.com</a></span>
        </div>
    </div>
</div>
    </footer>
    <!-- BEGIN VENDOR JS-->
    <script src="{{ url() }}/public/front/home/theme-assets/vendors/vendors.min.js"></script>
  
    <script src="{{ url() }}/public/front/home/theme-assets/vendors/flipclock/flipclock.min.js"></script>
    <script src="{{ url() }}/public/front/home/theme-assets/vendors/swiper/js/swiper.min.js"></script>
    <script src="{{ url() }}/public/front/home/theme-assets/vendors/particles.min.js"></script>
    <script src="{{ url() }}/public/front/home/theme-assets/vendors/waypoints/jquery.waypoints.min.js"></script>
    <script src="{{ url() }}/public/front/home/theme-assets/js/theme.js"></script>
    <script src="{{ url() }}/public/front/home/theme-assets/js/scripts/particles-type1.js"></script>
    <!-- END PAGE LEVEL JS-->
  </body>
</html>
