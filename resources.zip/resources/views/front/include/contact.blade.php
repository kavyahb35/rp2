<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>

<!--/ Contact -->
<section id="contact" class="contact section-padding">
    <div class="container-fluid">
        <div class="container">
            <div class="heading text-center">
                <div class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.3s">
                    <h6 class="sub-title">JOIN US</h6>
                    <h2 class="title">Contact</h2>
                </div>
                <p class="content-desc animated" data-animation="fadeInUpShorter" data-animation-delay="0.4s">Have questions? We’re happy to help.</p>

                <p class="font-medium mt-5 animated" data-animation="fadeInUpShorter" data-animation-delay="0.5s">Contact us with any questions regarding Crypto ICO.</p>
            </div>
            <div class="row">
                <div class="col-lg-5 col-md-12 mx-auto">
                    <ul class="list-unstyled list-group contact-info mb-3">
                        <li class="pt-1 animated" data-animation="fadeInUpShorter" data-animation-delay="0.6s">
                            <i class="ti-location-pin"></i>
                            <span>Kelley A. Fleming 96 Woodside USA.</span>
                        </li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.7s">
                            <i class="ti-email"></i>
                            <span>info@rewards2pay.com</span>
                        </li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.8s">
                            <i class="ti-comment-alt"></i>
                            <span>Join us on Telegram</span>
                        </li>
                        <li class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.9s">
                            <i class="ti-headphone"></i>
                            <span>+44 0123 4567</span>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-7 col-md-12 mx-auto">
                    <div id="succmsger" style="color:green"></div>
                    <div id="succmsger1" style="color:red"></div>
                    <form  method="post" name="contactfrm" id="contactfrm" accept-charset="utf-8" class="text-center">
                        <input type="text" class="form-control animated" data-animation="fadeInUpShorter" data-animation-delay="0.7s" name="fname" id="fname" placeholder="Your Name" required>
                        <input type="email" class="form-control animated" data-animation="fadeInUpShorter" data-animation-delay="0.8s" name="cemail" id="cemail" placeholder="Your Mail" required>
                        <input type="text" class="form-control animated" data-animation="fadeInUpShorter" data-animation-delay="0.9s" name="subject" id="subject" placeholder="Your Subject" required>
                        <textarea rows="4" class="form-control animated" data-animation="fadeInUpShorter" data-animation-delay="1.0s" name="message" id="message" placeholder="Your Massage" required></textarea>
                        <button type="submit" id="btn-submit" class="btn btn-lg btn-gradient-purple btn-glow float-right animated" data-animation="fadeInUpShorter" data-animation-delay="1.1s">Send Message <small id="loadingImg" style="display:none"><img src="<?php //echo base_url('assets/front/loader/spin.gif')?>"></small></button>
                    </form>
                     <script>
          //form validation rules
        
          $("#contactfrm").validate({
            rules: {
				
              fname: "required",
              message: "required",
              cemail: "required",
              subject: "required",
            }
            ,
            messages: {
              subject: "Please enter Subject ",
              fname: "Please enter  Name",
              cemail: "Please enter Email",
              message: "Please enter Message",
            }
            ,
            submitHandler: function(form) {
                 $("#loadingImg").show();
                 $(this).find("#btn-submit").prop('disabled', true);
                  var url="front/contact";
          var fname = $("#fname").val();
          var message = $("#message").val();
          var subject = $("#subject").val();
          var cemail = $("#cemail").val();
          
         
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "fname="+fname+"&message="+message+"&cemail="+cemail+"&subject="+subject,
                success: function (data) {
                    $("#loadingImg").hide();
                  if(data.success!=''){
                    $("#message").val('');
                      $("#cemail").val('');
                      $("#subject").val('');
                      $("#fname").val('');
                      $('#succmsger').html(data.success).delay(3000).fadeOut();
                      
                  }
                  if(data.error!=''){
                       $('#succmsger1').html(data.error).delay(3000).fadeOut();
                  }
                }
              });
            }
          }
         );
        </script>
                </div>
            </div>

        </div>
    </div>
</section>
<style>
label.error {
    color: red;
    float: left;
}
</style>
<!--/ Contact -->
