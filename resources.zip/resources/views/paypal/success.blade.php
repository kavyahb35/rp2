@include('customer.include.master.header')
<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
      </div>
      <div class="content-body">
         <section class="flexbox-container account-content" id="account-login">
            <div id="particles-js"></div>
            <div class="login-content container-fluid">
               <div class="col-12 d-flex align-items-center justify-content-center">                
                  <div class="col-xl-8 col-lg-6 col-md-6 col-sm-8 col-12 p-0">
                     <div class="border-grey border-lighten-3 m-0 box-shadow-0 card-account-right height-500">
                        <div class="card-content">
                           <div class="card-body p-3 account-bg-gradient">
                              <p class="text-center account-logo"><a href="{{ url() }}"><img src="{{ url() }}/public/front/home/theme-assets/images/account-logo.png"" alt="Rewards2pay" /></a></p>
                              <p class="txt"> Congratulation your balance has successfully done. once confirm our team has a release amount in your account. </p>
                              <p id="loadingImg" class="details"><img src="{{ url() }}/public/front/loader/spin.gif"></p>
                              <div class="details">
                                <p>Transaction ID : <b><?php echo session()->get('txnid'); ?></b></p>
                                <p>Amount : <b>$ <?php echo session()->get('paypalbalance');?> </b></p>
                                <p>Payment Status : <b>Pending</b></p>
                                </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   </div>
</div>
<script>    
    var url ="accesspayment";
    $("#loadingImg").show();
    setTimeout(function(){
       window.location.href = url ;
    }, 4000);
</script>

@include('customer.include.master.footer')

