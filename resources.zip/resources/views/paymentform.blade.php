<form action="buy" method="Post" name="frmTransaction" id="frmTransaction">
    <input type="hidden" name="business" value="sumit@cueserve.com"> 
    <input type="hidden" name="cmd" value="_xclick"> 
     <input type="text" name="item_name" value="test watch"> 
    <input type="text" name="item_number" value="1">
    <input type="text" name="amount" value="2">   
    <input type="hidden" name="currency_code" value="USD">   
     <input type="hidden" name="_token" value="{{ csrf_token() }}">
    <input type="hidden" name="cancel_return" value="http://localhost/04laravel/R2P/cancel"> 
    <input type="hidden" name="return" value="http://localhost/04laravel/R2P/success">
    <input type="hidden" name="notify_url" value="http://localhost/04laravel/R2P/ipn">
    <input type="submit" name="submit" value="submit">
    
</form>
