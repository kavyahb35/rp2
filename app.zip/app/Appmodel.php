<?php

namespace App;
use DB;

use Illuminate\Database\Eloquent\Model;
class Appmodel extends Model
{
    
    public function __construct()
    {
        parent::__construct();
    }
 
    
    function authgenerate()
    {        
        $accessToken = session()->get('accessToken');
        $apiurl = config('constants.Api_Url');
        $flag = config('constants.Usedstaticdata');
        
		
        if($accessToken==''){ 
            
            if($flag==1){	
               $apiurl = $apiurl.'apicontroller/getfileresponse?filename=authtoken.json';
              
               $datas = array('filename'=>"authtoken.json");
               $senddata = json_encode($datas);
               
            }
            else{
                $apiurl = $apiurl."oauth/client_credential/accesstoken?grant_type=client_credentials";
                $senddata = "client_id=rAvfnUt4WNtGYnEZMb1CI0QmhNrFP01c&client_secret=UtQhr3OslYIS4PBP";
            }
            $curl = curl_init();
            curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/x-www-form-urlencoded"
            ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
			
            curl_close($curl);
            if ($err) { 
                $path=base_url('fakedb/authtoken.json');
                    $str = file_get_contents($path);
                    $respe = json_decode($str, true);
                    
                    session()->put('accessToken', $respe['access_token']);
                    session()->put('status', $response['status']);
                    session()->put('client_id', $response['client_id']);
                   
                    
            } else {                 
                    $data = 'success';
                    $response=json_decode($response);
                    session()->put('accessToken', $response->access_token);
                    session()->put('status', $response->status);
                    session()->put('client_id', $response->client_id);
                    
                    return $data;
            }
        }       
    }
   
   public function password_strength_check($password, $min_len = 8, $max_len = 70, $req_digit = 1, $req_lower = 1, $req_upper = 1, $req_symbol = 1)
    {
        $regex = '/^';
        if ($req_digit > 0) {
            $regex .= '(?=.*\d)';
        } 
        if ($req_lower > 0) {
            $regex .= '(?=.*[a-z])';
        } 
        if ($req_upper > 0) {
            $regex .= '(?=.*[A-Z])';
        } 
        if ($req_symbol > 0) {
            $regex .= '(?=.*[^a-zA-Z\d])';
        } 
        $regex .= '.{' . $min_len . ',' . $max_len . '}$/';
        
        if (preg_match($regex, $password)) {
            return 1;
        } else {
            return 0;
        }
    } 

   public function user_strength_check($password, $min_len = 8, $max_len = 70, $req_digit = 1, $req_lower = 1, $req_upper = 1, $req_symbol = 1)
    {
        $regex = '/^';
        if ($req_digit > 0) {
            $regex .= '(?=.*\d)';
        } 
        if ($req_lower > 0) {
            $regex .= '(?=.*[a-z])';
        } 
        
        $regex .= '.{' . $min_len . ',' . $max_len . '}$/';
        
        if (preg_match($regex, $password)) {
            return 1;
        } else {
            return 0;
        }
    } 

   
    public function checkCustomerAuthenticate()
    {
		$cuserToken = session()->get('cuserToken');
		if($cuserToken==''){
			 return redirect('sign-in');
		}
	}
   
    public function authgeneratennn()
    {
		$eml ='test';
		session()->put('Loginemail', $eml);
	}
	public function getsession()
	{
		echo session()->get('accessToken');
	}

}


