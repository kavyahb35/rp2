<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class WalletController extends Controller {
    public function index()
    {
		
        $data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
		
		  
        if($flag==true){          
            $apiurl = $apiurl.'apicontroller/getfileresponse?filename=allprogramlist.json';
			$datas = array('filename'=>"allprogramlist.json");
			$senddata = json_encode($datas);
            
            $apiurl1 = config('constants.Api_Url');
            $apiurl1 = $apiurl1.'apicontroller/getfileresponse?filename=userprogramlistmy.json';
            $senddata1 = array('filename'=>"userprogramlistmy.json");
        }
        else{
			$partnerId = config('constants.PartnerId');
			$partnerName = config('constants.PartnerName');
            
			
            $apiurl  = $apiurl.'getloyaltyprograminfo/';
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);         
            $senddata = json_encode($partnerInfo); 
            
            $apiurl1 =config('constants.Api_Url');
            $apiurl1 = $apiurl1.'fetchUserRewards/';
            
            $partnerInfo1 = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials1 = array('userName'=>$username ,'userToken'=>$userToken);
            $merge1 = array('partnerInfo'=>$partnerInfo1,'credentials'=>$credentials1);
            $senddata1 = json_encode($merge1);

        }  
        
          $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($response)){
             $respe = json_decode($response); 
             //echo '<pre>';print_r($respe);die;
          }              
        }
       
        // -- for get perticular user  program
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl1,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata1,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $responses = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($responses)){
             $respes = json_decode($responses); 
             
          }              
        }
        
         $data['success'] = $this->arrayMerge($respe, $respes);
		return view('customer/afterlogin/wallet',$data);
    }
    public function arrayMerge($first,$second)
    {
       
        $new = array();
        foreach($first as $key => $value){
            foreach($second as $value2){  
                // echo '<pre>';print_r($value2->progId);die;
                if($value->progId === $value2->progId){  
                    $new[] = array(
                        'progId'=>$value2->progId,
                        'programName'=>$value2->programName,
                        'pointBalance'=>$value2->pointBalance,
                        'pointBalance1'=>$value2->pointBalance1,
                        'pointsSoftBalance'=>$value2->pointsSoftBalance,
                        'lastUpdated'=>$value2->lastUpdated,
                        'active'=>$value2->active,
                        'canRedeem'=>$first[$key]->canRedeem,
                        'minimumBalance'=>$first[$key]->minPointsEntered,
                        'cashBalance'=>$value2->cashBalance                       
                    );
                    
                    
                }               
            }
        }
        return $new;
    }
    public function refreshpoins()
    {
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
        if($_POST){
		  $programid = $_POST['programid'];	
		  if($flag==true){	
				$apiurl = $apiurl.'apicontroller/getfileresponse?filename=refreshrewardspointsvalid.json';
				$datas = array('filename'=>"refreshrewardspointsvalid.json");
				$senddata = json_encode($datas);
			}
			else{
				
                
				$apiurl  = $apiurl.'refreshPointBalance/';
				$partnerId = config('constants.PartnerId');
				$partnerName = config('constants.PartnerName');
			    
                 $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
				$credentials = array('userName'=>$username ,'userToken'=>$userToken);
				$rewardsProgramInfo = array('progId'=>$programid);
				$merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardsProgramInfo'=>$rewardsProgramInfo);
				$senddata = json_encode($merge);
			}
		}
		 $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
         $data['error']=$err;
        } else {
         if(!empty($response)){
             $respe = json_decode($response);
             if(!empty($respe)){
                $data['succ']='1';
                }else{
					$data['err']='2';
                 $error = $respe->message;
                  $contact = base_url();
                 $error .='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                 $data['error']=$error;
				}
             echo json_encode($data);
          }              
        }
	}
	public function removepoins()
    {
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
        if($_POST){
		  $programid = $_POST['programid'];	
		  if($flag==true){	
				$apiurl = $apiurl.'apicontroller/getfileresponse?filename=removerewardspoinsvalid.json';
				$datas = array('filename'=>"removerewardspoinsvalid.json");
				$senddata = json_encode($datas);
			}
			else{
                
				$apiurl  = $apiurl.'removeUserRewards/';
				$partnerId = config('constants.PartnerId');
				$partnerName = config('constants.PartnerName');
			    
				
				$partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
				$credentials = array('userName'=>$username ,'userToken'=>$userToken);
				$rewardsProgramInfo = array('progId'=>$programid);
				$merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
				$senddata = json_encode($merge);
			}
		}
		 $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));


        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
         $data['error']=$err;
         $data['err'] ='2';
         echo json_encode($data);
        } else {
          if(!empty($response)){
             $respe = json_decode($response);
             if($respe->statusMessage!=''){
                $data['success'] = $respe->statusMessage;
                $statusCode=$respe->statusCode;
                if($statusCode=='0'){
                    $data['success'] = $respe->statusMessage;
                   $data['err']='2';
                }
                if($statusCode=='1'){
                    $data['error'] = $respe->statusMessage;
                    $data['succ']='1';
                }
               
                }else{
					$data['err']='2';
                 $error = $respe->message;
                 $contact = base_url();
                 $error .='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                 $data['error']=$error;
				}
             echo json_encode($data);
          }
              
        }
	}
	public function redeemvaluefuncion()
    {
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
        if($_POST){
			$programid = $_POST['programid'];	
			$programidname = $_POST['programidname'];	
			$minimumBalance = $_POST['minimumBalance'];	
			$redeemvalue = $_POST['redeemvalue'];	
			$cashvalue = $_POST['cashvalue'];	
			$pointBalance = $_POST['pointBalance'];	
			$err ='';
			$minimumBalance1 = $minimumBalance;
			if($redeemvalue < $minimumBalance1){
				$err .= 'You have entered insufficient balance points to redeem.';
			}
			if($redeemvalue > $pointBalance){
				$err .= 'You have entered insufficient balance points to redeem.';
			}
			if($pointBalance==''){
				$err .= 'Point balance field required';
			}
			if($err != ''){
				$data['error'] = $err;
                $data['error']=str_ireplace('</p>','',$data['error']);
                $data['error']=str_ireplace('<p>','',$data['error']);
                $data['err']='2';
                echo json_encode($data);
				
			}else{
				
			  if($flag==true){	
					$apiurl = $apiurl.'apicontroller/getfileresponse?filename=redeempointbalancevalid.json';
					$datas = array('filename'=>"redeempointbalancevalid.json");
					$senddata = json_encode($datas);
				}
				else{
					
					$apiurl  = $apiurl.'redeempointsorcash/';
					$partnerId = config('constants.PartnerId');
					$partnerName = config('constants.PartnerName');
					
					$partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
					$credentials = array('userName'=>$username ,'userToken'=>$userToken);
					$rewardsProgramInfo = array('progId'=>$programid,'pointBalance1'=>$redeemvalue,'cashBalance'=>$cashvalue,'cpFlag'=>'P');
					$merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
					$senddata = json_encode($merge);
				}
				$curl = curl_init();
				curl_setopt_array($curl, array(
				  CURLOPT_URL => $apiurl,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => $senddata,
				  CURLOPT_HTTPHEADER => array(
					"Content-Type: application/json",
					"access-token: ".$accessToken
				  ),
				));


				$response = curl_exec($curl);
				$err = curl_error($curl);

				
				curl_close($curl);
				if ($err) {
				 $data['error']=$err;
				 $data['err'] ='2';
				 echo json_encode($data);
				} else {
				  if(!empty($response)){
					 $respe = json_decode($response);
					
					 //$errormsg = $respe->message;
					 $errormsg = '';
					 if(!empty($respe)){
						 if($errormsg!=''){
							 $data['error'] = $errormsg;
							  $data['err']='2';
						 }else{
							if($respe->progId!=''){
									$data['pointBalance1']=$respe->pointBalance1;
									$data['cashBalance']=$respe->cashBalance;
									$data['succ']='1';
									 

							 }else{
									$contact = base_url();
									$data['error']='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
									$data['err']='2';
								 }
						 }
					 }
					
					 echo json_encode($data);
				  }

				}
			}
			 
	     }
	}
     

     public function cashvaluefuncion()
    {
       $data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
        if($_POST){
			$programid = $_POST['programid'];	
			$programidname = $_POST['programidname'];	
			$minimumBalance = $_POST['minimumBalance'];	
			$redeemvalue = $_POST['redeemvalue'];	
			$cashvalue = $_POST['cashvalue'];	
			$pointBalance = $_POST['pointBalance'];	
			$err ='';
			$minimumBalance1 = $minimumBalance;
			
			if($cashvalue==''){
				$err .= 'Cash balance field required';
			}
			if($err != ''){
				$data['error'] = $err;
                $data['error']=str_ireplace('</p>','',$data['error']);
                $data['error']=str_ireplace('<p>','',$data['error']);
                $data['err']='2';
                echo json_encode($data);
				
			}else{
				
			  if($flag==true){	
					$apiurl = $apiurl.'apicontroller/getfileresponse?filename=redeempointbalancevalid.json';
					$datas = array('filename'=>"redeempointbalancevalid.json");
					$senddata = json_encode($datas);
				}
				else{
					
					$apiurl  = $apiurl.'redeempointsorcash/';
					$partnerId = config('constants.PartnerId');
					$partnerName = config('constants.PartnerName');
					
					$partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
					$credentials = array('userName'=>$username ,'userToken'=>$userToken);
					$rewardsProgramInfo = array('progId'=>$programid,'pointBalance1'=>$redeemvalue,'cashBalance'=>$cashvalue,'cpFlag'=>'C');
					$merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
					$senddata = json_encode($merge);
				}
				$curl = curl_init();
				curl_setopt_array($curl, array(
				  CURLOPT_URL => $apiurl,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => $senddata,
				  CURLOPT_HTTPHEADER => array(
					"Content-Type: application/json",
					"access-token: ".$accessToken
				  ),
				));


				$response = curl_exec($curl);
				$err = curl_error($curl);

				
				curl_close($curl);
				if ($err) {
				 $data['error']=$err;
				 $data['err'] ='2';
				 echo json_encode($data);
				} else {
			  if(!empty($response)){
					 $respe = json_decode($response);
					
					 //$errormsg = $respe->message;
					 $errormsg = '';
					 if(!empty($respe)){
						 if($errormsg!=''){
							 $data['error'] = $errormsg;
							  $data['err']='2';
						 }else{
							if($respe->progId!=''){
									$data['pointBalance1']=$respe->pointBalance1;
									$data['cashBalance']=$respe->cashBalance;
									 $data['succ']='1';

							 }else{
									$contact = base_url();
									$data['error']='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
									$data['err']='2';
									 }
						 }
					 }
					
					 echo json_encode($data);
				  }


				}
			}
			 
	     }
       
    }
     
}











