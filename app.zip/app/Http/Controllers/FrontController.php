<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class FrontController extends Controller {
	public function index()
	{      
        //$data['title']='Rewards2pay';		
        $tag = new Appmodel();
       // $tag->authgenerate();  
        //$tag->getsession();
         
		return view('front/front');
	}
	public function indexbl()
	{      
        //$data['title']='Rewards2pay';		
        $tag = new Appmodel();
        $tag->authgenerate();  
        //$tag->getsession();
         
		return view('front/front');
	}
	public function contact()
	{	
		$fname = $_POST['fname'];
		$message = $_POST['message'];
		$cemail = $_POST['cemail'];
		$subject = $_POST['subject'];
		 $to = DB::table('r2p_contact')->insertGetId(
                   array(               
                    'UserName' => $fname,
					'Email' => $cemail,
					'Subject' => $subject,
					'Message' => $message,
					'Created' => date('Y-m-d')

                         )
                );
       /*   $message = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
                        <img src="http://r2p.cueserve.com/assets/front/home/theme-assets/images/logo.png">
                        </h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">

                        Thank You for Contact us. We will get back to soon. <br>


                        </div>
                        <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Rewards2Pay.com.</p>
                        </div></div></div></div>';
            
            $from_email = "info@rewards2pay.com";
           
                                    //Load email library 
            //------mail function ------------------------------------------
            $name = $_POST['fname'];
			$message = $_POST['message'];
			$email = $_POST['cemail'];
			$subject = $_POST['subject'];
			
           
            $to = $cemail;
            $subject = "Thank you for Contact us with rewards2pay.com";

            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: info@rewards2pay.com";

            $message = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
                        Rewards2pay.com
                        </h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">

                        Thank You for Contact us. We will get back to soon. <br>


                        </div>
                        <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Rewards2Pay.com.</p>
                        </div></div></div></div>';


            mail($to,$subject,$message,$headers);

             $message1 = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
                        Rewards2pay.com
                        </h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">

                   <h3> Contact Details </h3><br>
            Name : '.$name.' <br>
            Email : '.$email .' <br>
            Subject: '.$subject.' <br>
            Message: '.$message.' <br>


            </div>

            </div></div>';
            $to12 = "info@rewards2pay.com";
            mail($to12,$subject,$message1,$headers);*/

			//--------------------------------------------------
           $data['success']='Thank you for Contact us. We will get back soon.';
           echo json_encode($data);
	}
	
	
	
   
}












