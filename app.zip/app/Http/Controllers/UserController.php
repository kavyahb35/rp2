<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller {
    public function index()
    {
        $data['success']='';
        $data['error']='';
        $data['errorflash']='';
        $data['successflash']='';

        //print_r($_POST);
        $accessToken = session()->get('accessToken');
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');


		if($_POST){
		$username = $_POST['username'];
		$password = $_POST['password'];

         if($flag==true){	
            if($username=='user' && $password=='user'){}else{
                $error ='Username and password does not exist.';
                $data['error'] =$error;
            }
        }
        $partnerId = config('constants.PartnerId');
        $partnerName = config('constants.PartnerName');

        if($flag==true){	
                $apiurl = $apiurl.'apicontroller/getfileresponse?filename=loginsuccessapi.json';
                $datas = array('filename'=>"loginsuccessapi.json");
                $senddata = json_encode($datas);
        }
        else{ 
             $apiurl = config('constants.Api_Url');
            $apiurl=$apiurl.'loginuser/';
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'newPassword'=>$password);	
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
            $senddata = json_encode($merge);
        }

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $apiurl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $senddata,
        CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        "access_token: ".$accessToken
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            $data['error'] = $err;
        } else {
            $respe = json_decode($response); 
            if(isset($respe->message)){
				$data['error'] = $respe->message;
			}else{
				$usetoken = $respe->userToken;
				if($usetoken!=''){						
              //  echo $usetoken;die;
                 session()->put('cid', $respe->id);
                 session()->put('cfirstName', $respe->firstName);
                 session()->put('clastName', $respe->lastName);
                 session()->put('cuserEmail', $respe->userEmail);
                 session()->put('cuserToken', $respe->userToken);
                 session()->put('ctokenCreated', $respe->tokenCreated);
                 session()->put('cusername', $username);
                 session()->put('coldpassword', $password);


				 session()->put('coldpassword', $respe->wallet->walletBalance);
				 session()->put('coldpassword', $respe->wallet->softWalletBalance);
				 session()->put('coldpassword', $respe->wallet->estimatedWalletValue);
				

                $data['success'] = 'Login Successfully';
                return redirect('dashboard');
              //  redirect('dashboard');
            }else{
                $data['error'] = 'Invalid Username and Password';		
                }
			}
			
        }

    }

            return view('customer/useraccess/login',$data);
    }
     public function forgotpasword()
    {
		//print_r($_POST);die;
		$partnerId = config('constants.PartnerId');
        $partnerName = config('constants.PartnerName');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		
        $data['success']='';
        $data['error']='';
        if($_POST){
         $accessToken = session()->get('accessToken');
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
        
         
         if($flag==true){		
                    $apiurl = $apiurl.'apicontroller/getfileresponse?filename=resetapiresponse.json';
                    $datas = array('filename'=>"resetapiresponse.json");
                    $senddata = json_encode($datas);
		}
		else{
                    $apiurl=$apiurl.'resetPassword/';
                    $username = $_POST['username'];
                    $credentials = array('userName'=>$username);
                    $senddata = json_encode($credentials);
                }
                $curl = curl_init();		
                curl_setopt_array($curl, array(
                    //CURLOPT_PORT => "8080",
                    CURLOPT_URL => $apiurl,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $senddata,
                    CURLOPT_HTTPHEADER => array(
                        "Content-Type: application/json"
                    ),
                ));
                $response = curl_exec($curl);
                $err = curl_error($curl);			

                if ($err) {
                    $data['error']=$err;
                } else {
                    $respe = json_decode($response);		
                    $resetToken = $respe->userToken;
                    
                    if($resetToken!=''){
                                           
                        
                        $data['success']= 'Please check your E-mail for reset password link. ';
                    }else {
                        if($respe->message!=''){
                            $data['error']='Information provided to reset password is invalid';	
                        }
                    }
                }
			}
		return view('customer/useraccess/forgotpassword',$data);
	}

	
    public function register()
    {
		$data = array();		
		$data['success'] ='';
		$data['error'] = '';
		$data['firstname'] = '';
		$data['lastname'] = '';
		$data['username'] = '';
		$data['email'] = '';
		$data['address'] = '';
		$data['city'] = '';
		$data['province'] = '';
		$data['zipcode'] = '';
		$data['phone'] = '';
		$data['dob'] = '';
		
		$partnerId = config('constants.PartnerId');
        $partnerName = config('constants.PartnerName');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$tag = new Appmodel();
		$accessToken = session()->get('accessToken');
		$err ='';
        if($accessToken=='')
        {
                 
           $tag->authgenerate();  
        }
        if($_POST){
			$password = $_POST['password'];
			$pwdcheck = $tag->password_strength_check($password);
			 
			 if ($pwdcheck == '0') {
				//$err .= 'Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.';
			}
			$confirmpassword = $_POST['cpassword'];
			if($password != $confirmpassword)
			{
			    $err .= 'Password and Confirm password does not match';	
			}
			$username = $_POST['username'];
			$usercheck = $tag->user_strength_check($password);
			if($usercheck == '0')
			{
			    $err .= 'Minimum 7 char required. Password must contain at least 1 lowercase, 1 digit character.';	
			}
			if($err!=''){ 
				    $data['error'] = $err;
			}else{ 
				$firstname = $_POST['firstname'];
				$lastname = $_POST['lastname'];
				$username = $_POST['username'];
				$email = $_POST['email'];
				$password = $_POST['password'];
				$cpassword = $_POST['cpassword'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				$province = $_POST['province'];
				$zipcode = $_POST['zipcode'];
				$country = $_POST['country'];
				$phone = $_POST['phone'];
				$dob = $_POST['dob'];
				$phone = str_replace("-","",$phone);
				$phone = str_replace(" ","",$phone);

                $newaddress = $address.' , '.$city.' , '.$province.','.$zipcode.' , '.$country;
                
                if($flag==true){
                    $apiurl = $apiurl.'apicontroller/getfileresponse?filename=registerapiresponse.json';
                    $datas = array('filename'=>"registerapiresponse.json");
                    $senddata = json_encode($datas);
				}
				else{
							$apiurl = $apiurl.'registerUser/';
							$credentials = array('userName'=>$username ,'newPassword'=>$password);
							$userDetails = array(
								'firstName'=>$firstname,
								'lastName'=>$lastname,
								'address'=>$newaddress,
								'phone'=>$phone,
								'userEmail'=>$email,
								'zipCode'=>$zipcode,
								'dob'=>$dob,
							);

							$merge = array('credentials'=>$credentials,'userDetails'=>$userDetails);
							$senddata = json_encode($merge);
						}
				$curl = curl_init();
                curl_setopt_array($curl, array(
                    //CURLOPT_PORT => "8080",
                    CURLOPT_URL => $apiurl,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $senddata,
                    CURLOPT_HTTPHEADER => array(
                        "Content-Type: application/json",
                        "access-token: ".$accessToken
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);

                if ($err) {
                    $response = json_decode($response);
                   // $status = $response->error;
                   // $error = $response->message;
                    $data['error'] = 'Please contact us';
                } else {
                    $response = json_decode($response);        
                    
                    if(!empty($response)){
						if(isset($response->statusCode)){
						  $status = $response->statusCode;
						  if($status=='1'){
								$data['success'] = $response->statusMessage;
						  }
						}
						else{
							$eoor = $response->message;
							if($eoor!=''){
							$data['error'] = $response->message;
							}
						}
					}           
                   
                    
                }
				
			}
		}
		
		 return view('customer/useraccess/register',$data);
    }
    public function updateresetPassword($username='',$token='')
   {   
	   
	   $data = array();
	    $partnerId = config('constants.PartnerId');
        $partnerName = config('constants.PartnerName');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		
        $data['username']=$username;
        $data['token']=$token;
        $data['error'] =''; 
        $data['success'] =''; 
         $tag = new Appmodel();
        if($_POST){
			
			$accessToken = session()->get('accessToken');
			if($accessToken=='')
			{
					
				$tag->authgenerate();  
			}
			$err =''; 
			 $username = $_POST['username'];
			$password = $_POST['password'];
			$jk = $tag->password_strength_check($password);
			 
			 if ($jk == '0') {
				$err .= 'Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.';
			}
			$confirmpassword = $_POST['confirmpassword'];
			if($password != $confirmpassword)
			{
			    $err .= 'Password and Confirm password does not match';	
			}
			if($err!=''){ 
				    $data['error'] = $err;
			}else{ 
				if($flag==true){	
							$apiurl = $apiurl.'apicontroller/getfileresponse?filename=updatepasswordresponse.json';
							$datas = array('filename'=>"updatepasswordresponse.json");
							$senddata = json_encode($datas);
				}
				else{
							$apiurl=$apiurl."updatePassword/?authToken=".$token;                    
							$partnerInfo = array('userName'=>$username ,'password'=> $password,'newPassword'=> $confirmpassword);
							$senddata = json_encode($partnerInfo);
							$token = $token;  
				}
				
				
				
				if($token!=''){
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $apiurl,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $senddata,
                        CURLOPT_HTTPHEADER => array(
                            "Content-Type: application/json"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    curl_close($curl);
						
                    if ($err) {
                       $data['error']='Reset Password token Expired.';
                    } else {
                        $respe = json_decode($response); 

                       
                       if($respe->statusCode=='1'){		
                          $data['success'] = $respe->statusMessage;
                          
                       }else{
						   
						    $data['error'] = $respe->statusMessage;
						  }
                    }
				}else{
					$data['error']='Reset Pasword token Expired.';
					  $this->session->set_flashdata('error', 'Reset Password token Expired.');
					return redirect('sign-in');
                }

			}
		}
		
      return view('customer/useraccess/resetpasswordregister',$data);
   }
   
   
    public function dashboard_bkup()
    {
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		 
		if($flag==true){      
			$apiurl = $apiurl.'apicontroller/getfileresponse?filename=allprogramlist.json';    
            $datas = array('filename'=>"allprogramlist.json");
            $senddata = json_encode($datas);
            
            $apiurl1 = config('constants.Api_Url');
            $apiurl1 = $apiurl1.'apicontroller/getfileresponse?filename=userprogramlistmy.json';
            $senddata1 = array('filename'=>"userprogramlistmy.json");
        }
        else{
            
            $apiurl  = $apiurl.'getloyaltyprograminfo/';
            $partnerId = config('constants.PartnerId');
            $partnerName = config('constants.PartnerName');

            
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);         
            $senddata = json_encode($partnerInfo);
            
                        
            $apiurl1 = config('constants.Api_Url');
            $apiurl1  = $apiurl1.'fetchUserRewards/';
            $partnerInfo1 = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials1 = array('userName'=>$username ,'userToken'=>$userToken);
            $merge1 = array('partnerInfo'=>$partnerInfo1,'credentials'=>$credentials1);
            $senddata1 = json_encode($merge1);
        }
         $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($response)){
             $respe = json_decode($response); 
             //echo '<pre>';print_r($respe);die;
          }              
        }
       
        // -- for get perticular user  program
       
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl1,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata1,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $responses = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($responses)){
             $respes = json_decode($responses); 
          }              
        }
      //    include 'barcode.php';  
       // $data['generator'] = new barcode_generator();
        $data['success'] = $this->arrayMerge($respe, $respes);
       
        
         echo 'Welcome : ' .session()->get('cfirstName').' '.session()->get('clastName');
    }
    
    public function arrayMerge($first,$second)
    {
        $new = array();
        foreach($first as $key => $value){
            foreach($second as $value2){  
                if($value->progId === $value2->progId){  
                    $new[] = array(
                       'progId'=>$value2->progId,
                        'programName'=>$value2->programName,
                        'pointBalance'=>$value2->pointBalance,
                        'pointBalance1'=>$value2->pointBalance1,
                        'pointsSoftBalance'=>$value2->pointsSoftBalance,
                        'lastUpdated'=>$value2->lastUpdated,
                        'active'=>$value2->active,
                        'canRedeem'=>$first[$key]->canRedeem,
                        'minimumBalance'=>$first[$key]->minPointsEntered,
                        'canBarcodeStandard'=>$first[$key]->barcodeStandard,
                        'cashBalance'=>$value2->cashBalance,
                        'cardNumber'=>$value2->cardNumber                        
                    );
                    
                }               
            }
        }
        return $new;
    }
    
      
    public function dashboard()
    {
		$data['success'] ='';
		$data['success'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		 
		if($flag==true){      
			$apiurl = $apiurl.'apicontroller/getfileresponse?filename=allprogramlist.json';    
            $datas = array('filename'=>"allprogramlist.json");
            $senddata = json_encode($datas);
            
            $apiurl1 = config('constants.Api_Url');
            $apiurl1 = $apiurl1.'apicontroller/getfileresponse?filename=userprogramlistmy.json';
            $senddata1 = array('filename'=>"userprogramlistmy.json");
        }
        else{
            
            $apiurl  = $apiurl.'getloyaltyprograminfo/';
            $partnerId = config('constants.PartnerId');
            $partnerName = config('constants.PartnerName');

            
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);         
            $senddata = json_encode($partnerInfo);
            
                        
            $apiurl1 = config('constants.Api_Url');
            $apiurl1  = $apiurl1.'fetchUserRewards/';
            $partnerInfo1 = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials1 = array('userName'=>$username ,'userToken'=>$userToken);
            $merge1 = array('partnerInfo'=>$partnerInfo1,'credentials'=>$credentials1);
            $senddata1 = json_encode($merge1);
        }
         $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($response)){
             $respe = json_decode($response); 
             //echo '<pre>';print_r($respe);die;
          }              
        }
       
        // -- for get perticular user  program
       
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl1,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata1,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $responses = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($responses)){
             $respes = json_decode($responses); 
          }              
        }
        include 'barcode.php';  
	//	$data['generator'] =  barcode_generator();
        $data['success'] = $this->arrayMerge($respe, $respes);
       
		return view('customer/afterlogin/dashboard',$data);
	}
	
	public function logout()
	{
		$partnerId = config('constants.PartnerId');
        $partnerName = config('constants.PartnerName');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$username = session()->get('cusername');
		
		if($flag==true){				
			$apiurl = $apiurl.'apicontroller/getfileresponse?filename=logoutvalid.json';
			$datas = array('filename'=>"logoutvalid.json");
            $senddata = json_encode($datas);
        }
        else{
            $apiurl=$apiurl.'logoutUser/';
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);	
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);

            $senddata = json_encode($merge);
        }
        //echo 'dfsd';die;
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json"
          ),
        ));
        

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
           
        } else {
            $respe = json_decode($response);
            if(isset($respe->statusCode)){
            if($respe->statusCode=='1'){
                echo $respe->statusMessage;
            }else{
				 echo $respe->statusMessage;
				}
			}
        }
      
      session()->forget('cfirstName');
      session()->forget('clastName');
      session()->forget('cuserToken');
      
      
      session()->forget('ctokenCreated');
      session()->forget('cusername');
      
      session()->forget('coldpassword');    
      session()->forget('cid');
      return redirect('sign-in');
		
	}


    public function profile()
    {
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$data['address']='';
        $data['city']='';
        $data['zipcode']='';
        $data['province']='';
        $errmsg ='';
        
		
		 if($flag==true){
            $apiurl = $apiurl.'apicontroller/getfileresponse?filename=getuserprofile.json';
            $datas = array('filename'=>"getuserprofile.json");
            $senddata = json_encode($datas);
        }
        else{
            $apiurl = $apiurl.'getUserProfile/';
            $partnerId = config('constants.PartnerId');
			$partnerName = config('constants.PartnerName');
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
            $senddata = json_encode($merge);

        }
         $curl = curl_init();
        curl_setopt_array($curl, array(        
        CURLOPT_URL => $apiurl,       
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $senddata,
        CURLOPT_HTTPHEADER => array(
              "Content-Type: application/json",
              "access-token: ".$accessToken
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            $data['error'] = $err;
        } else {
            $respe = json_decode($response);	
             				
           // $errmsg = $respe->message;
            /*if($errmsg!=''){
            $data['error'] = $respe->message;
            }*/
			if(isset($respe->message)){
				$data['error'] = $respe->message;
			}else {
				if($respe->firstName!=''){
				   
					 session()->put('cid', $respe->id);
					 session()->put('cfirstName', $respe->firstName);
					 session()->put('clastName', $respe->lastName);
					 session()->put('cuserEmail', $respe->userEmail);
					 session()->put('lastUpdatedBy',  $respe->lastUpdatedBy);
					 session()->put('lastUpdate',  $respe->lastUpdate);
					 session()->put('caddress',  $respe->address);
					 session()->put('caltPhone',  $respe->altPhone);
					 session()->put('czipCode',  $respe->zipCode);
					 session()->put('ccity',  $respe->city);
					 session()->put('cdob',  $respe->dob);
					 session()->put('cstatus',  $respe->status);
					 session()->put('cresetCount',  $respe->resetCount);
					  session()->put('cphone',  $respe->phone);
					  
					   session()->put('coldpassword', $respe->wallet->walletBalance);
					 session()->put('coldpassword', $respe->wallet->softWalletBalance);
					 session()->put('coldpassword', $respe->wallet->estimatedWalletValue);

				}
			}
        }
       
		
	    return view('customer/afterlogin/profile',$data);	
	}
	public function updateprofile()
	{
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$data['address']='';
        $data['city']='';
        $data['zipcode']='';
        $data['province']='';
        $errmsg ='';
        
        if($_POST){
			
				$firstname = $_POST['firstname'];
				$lastname = $_POST['lastname'];
				$email = $_POST['email'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				$province = $_POST['province'];
				$zipcode = $_POST['zipcode'];
				$country = $_POST['country'];
				$dob = $_POST['dob'];
				 $accessToken = session()->get('accessToken');
				if($accessToken=='')
				{
						 $tag = new Appmodel();
						 $tag->authgenerate();  
				}
				if($phone=='' || $city=='' || $province=='' || $zipcode=='' || $dob==''){
					$data['error'] = 'All fields required';	
				}else{
					$phone = str_replace("-","",$phone);
					$phone = str_replace(" ","",$phone);
					if($flag==true){
						$apiurl = $apiurl.'apicontroller/getfileresponse?filename=updateprofilevalid.json';
						$datas = array('filename'=>"updateprofilevalid.json");
						$senddata = json_encode($datas);
					}
					else{
						$apiurl = $apiurl.'updateuser/';
						$partnerId = config('constants.PartnerId');
						$partnerName = config('constants.PartnerName');
						
						$zipcode = trim($zipcode);
						$newaddress = $address.'|'.$city.'|'.$province.'|'.$zipcode.'|'.$country;							
						
						$partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
						$credentials = array('userName'=>$username ,'userToken'=>$userToken);
						$userDetails = array(
							'firstName'=>$firstname,
							'lastName'=>$lastname,
							'address'=>$newaddress,
							'phone'=>$phone,
							'userEmail'=>$email,
							'zipCode'=>$zipcode,
							'dob'=>$dob,
						);
						$merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'userDetails'=>$userDetails);
						$senddata = json_encode($merge);
					}
						$curl = curl_init();
						curl_setopt_array($curl, array(
						CURLOPT_URL => $apiurl,
						CURLOPT_RETURNTRANSFER => true,
						CURLOPT_ENCODING => "",
						CURLOPT_MAXREDIRS => 10,
						CURLOPT_TIMEOUT => 30,
						CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						CURLOPT_CUSTOMREQUEST => "POST",
						CURLOPT_POSTFIELDS => $senddata,
						CURLOPT_HTTPHEADER => array(
							"Content-Type: application/json",
							"access-token: ".$accessToken
						),
						));

						$response = curl_exec($curl);
						$err = curl_error($curl);
                        
						curl_close($curl);
						if(!empty($response)){
							$resp = json_decode($response);
							 if(isset($resp->message)){
								 $data['error'] = $resp->message;
								} else {
									 $status = $resp->statusCode;
								if($status=='1'){
									$data['success'] = $resp->statusMessage;
								}else{
									$data['error'] = 'User must login to continue.';
								}
						  
								

								//---- get profile --------
								$apiurl = config('constants.Api_Url');
								$flag = config('constants.Usedstaticdata');
								
								if($flag==true){
									$apiurl = $apiurl.'apicontroller/getfileresponse?filename=getuserprofile.json';
									$datas = array('filename'=>"getuserprofile.json");
									$senddata = json_encode($datas);
								}
								else{
									$apiurl = $apiurl.'getUserProfile/';
									$partnerId = config('constants.PartnerId');
									$partnerName = config('constants.PartnerName');
									$partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
									$credentials = array('userName'=>$username ,'userToken'=>$userToken);
									$merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
									$senddata = json_encode($merge);

								}
								$curl = curl_init();
								curl_setopt_array($curl, array(        
								CURLOPT_URL => $apiurl,       
								CURLOPT_RETURNTRANSFER => true,
								CURLOPT_ENCODING => "",
								CURLOPT_MAXREDIRS => 10,
								CURLOPT_TIMEOUT => 30,
								CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
								CURLOPT_CUSTOMREQUEST => "POST",
								CURLOPT_POSTFIELDS => $senddata,
								CURLOPT_HTTPHEADER => array(
									  "Content-Type: application/json",
									  "access-token: ".$accessToken
								),
								));

								$response = curl_exec($curl);
								$err = curl_error($curl);
								curl_close($curl);

								if ($err) {
									$data['error'] = $err;
								} else {
									$respe = json_decode($response);					
								   

									if($respe->firstName!=''){
									   
										 session()->put('cid', $respe->id);
										 session()->put('cfirstName', $respe->firstName);
										 session()->put('clastName', $respe->lastName);
										 session()->put('cuserEmail', $respe->userEmail);
										 session()->put('lastUpdatedBy',  $respe->lastUpdatedBy);
										 session()->put('lastUpdate',  $respe->lastUpdate);
										 session()->put('caddress',  $respe->address);
										 session()->put('caltPhone',  $respe->altPhone);
										 session()->put('czipCode',  $respe->zipCode);
										 session()->put('ccity',  $respe->city);
										 session()->put('cdob',  $respe->dob);
										 session()->put('cstatus',  $respe->status);
										 session()->put('cresetCount',  $respe->resetCount);
										 session()->put('cphone',  $respe->phone);
										  
										 session()->put('coldpassword', $respe->wallet->walletBalance);
										 session()->put('coldpassword', $respe->wallet->softWalletBalance);
										 session()->put('coldpassword', $respe->wallet->estimatedWalletValue);

									}
									
								}
								
								}

							
						 }
						
					}
					
				}
			return view('customer/afterlogin/profile',$data);	
        
	}
	
	public function changepassword()
	{
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		
		 if($flag==true){
            $apiurl = $apiurl.'apicontroller/getfileresponse?filename=resetapiresponse.json';
            $datas = array('filename'=>"resetapiresponse.json");
            $senddata = json_encode($datas);
        }
        else{
            $apiurl = $apiurl.'resetPassword/';
			$credentials = array('userName'=>$username);
            $senddata = json_encode($credentials);
        }
          $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
              $data['error']=$err;
            } else {
                $respe = json_decode($response);					
                $resetToken = $respe->userToken;
                
                if($resetToken!=''){
					  session()->put('resetpwdtoken',  $resetToken);                   
                    return redirect('updatepassword');
                }else {
                   
                        $data['error']='Information provided to reset password is invalid';	
                   
                }
            }
		
		return view('customer/afterlogin/changepassword',$data);
	} 
	public function updatepassword()
	{
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		$err ='';
		if($_POST){
			$oldpassword = $_POST['oldpassword'];
			$password = $_POST['password'];
			$confirmpassword = $_POST['confirmpassword'];
			
			$password = $_POST['password'];
			$jk = $tag->password_strength_check($password);
			 
			if($jk == '0')
			{
				$err .= 'Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.';
			}
			if($coldpassword != $oldpassword)
			{
				$err .= 'Old Password does not matched';
			}
			if($err!=''){
			   $data['error'] = $err;	
			}else{
				$token = session()->get('resetpwdtoken');
				if($flag==true){	
                    $apiurl = $apiurl.'apicontroller/getfileresponse?filename=updatepasswordresponse.json';
                    $datas = array('filename'=>"updatepasswordresponse.json");
                    $senddata = json_encode($datas);
				}
				else{
					$apiurl=$apiurl."updatePassword/?authToken=".$token;
					$partnerInfo = array('userName'=>$username ,'password'=> $password,'newPassword'=> $confirmpassword);
					$senddata = json_encode($partnerInfo);
				}
				if($token!=''){
                        $curl = curl_init();
                        curl_setopt_array($curl, array(
                            CURLOPT_URL => $apiurl,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_ENCODING => "",
                            CURLOPT_MAXREDIRS => 10,
                            CURLOPT_TIMEOUT => 30,
                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                            CURLOPT_CUSTOMREQUEST => "POST",
                            CURLOPT_POSTFIELDS => $senddata,
                            CURLOPT_HTTPHEADER => array(
                                "Content-Type: application/json"
                            ),
                        ));

                        $response = curl_exec($curl);
                        $err = curl_error($curl);
                        curl_close($curl);
                        
                        //-------------------------------------------------------------------------------------------------
                        
                         if ($err) {
                          $data['error'] = $err;
						 } else {
								$respe = json_decode($response);				
								
								if($respe->statusCode=='1'){						
									$data['success']=$respe->statusMessage;				
									 $partnerId = config('constants.PartnerId');
									 $partnerName = config('constants.PartnerName');
									 $apiurl = config('constants.Api_Url');
									 $flag = config('constants.Usedstaticdata');
									 
									 $password = $_POST['password'];
									 $username = session()->get('cusername');
									if($flag==true){
										$apiurl = $apiurl.'apicontroller/getfileresponse?filename=loginsuccessapi.json';
										$datas = array('filename'=>"loginsuccessapi.json");
										$senddata = json_encode($datas);
									}
									else{
										$apiurl = config('constants.Api_Url');
										$apiurl=$apiurl.'loginuser/';
										$partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
										$credentials = array('userName'=>$username ,'newPassword'=>$password);	
										$merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
										$senddata = json_encode($merge);
									}                                
									
									$curl = curl_init();
									curl_setopt_array($curl, array(
									CURLOPT_URL => $apiurl,
									CURLOPT_RETURNTRANSFER => true,
									CURLOPT_ENCODING => "",
									CURLOPT_MAXREDIRS => 10,
									CURLOPT_TIMEOUT => 30,
									CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
									CURLOPT_CUSTOMREQUEST => "POST",
									CURLOPT_POSTFIELDS => $senddata,
									CURLOPT_HTTPHEADER => array(
									"Content-Type: application/json",
									"access_token: ".$accessToken
									),
									));

									$response = curl_exec($curl);
									$err = curl_error($curl);
									$respe = json_decode($response);
									$usetoken = $respe->userToken;
									if($usetoken!=''){
									session()->put('cid', $respe->id);
									 session()->put('cfirstName', $respe->firstName);
									 session()->put('clastName', $respe->lastName);
									 session()->put('cuserEmail', $respe->userEmail);
									 session()->put('cuserToken', $respe->userToken);
									 session()->put('ctokenCreated', $respe->tokenCreated);
									 session()->put('cusername', $username);
									 session()->put('coldpassword', $password);
									}else{
									$data['error'] = $respe->message;
									}
								}else{
									$data['error'] = $respe->statusMessage;
								}
						}
                        //--------------------------------------------------------------------------------------------------
				}else{
				     $data['error'] = 'Change Password token Expired.';	
				}
			}
			
		}
		return view('customer/afterlogin/changepassword',$data);
	}
}












