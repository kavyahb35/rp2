<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class TransactionController extends Controller {
    public function index()
    {
		
        $data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
		    
        if($flag==true){          
            $apiurl = $apiurl.'apicontroller/getfileresponse?filename=transactionvalid.json';
			$datas = array('filename'=>"transactionvalid.json");
			$senddata = json_encode($datas);
          
        }
        else{
			$partnerId = config('constants.PartnerId');
			$partnerName = config('constants.PartnerName');
			
            $apiurl  = $apiurl.'gettransactionhistory/';
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
            $senddata = json_encode($merge);
            
           

        }  
        
       $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($response)){
             $respe = json_decode($response);
             $data['success']=$respe;
             $data['succ']='1';
          }              
        }
		//echo '<pre>';   
		//print_r($data);die;
		return view('customer/afterlogin/transaction',$data);
    }
  
     

}











