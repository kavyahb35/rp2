<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class PaypalController extends Controller {
  
   public function index()
	{     
		 return view('paymentform');
	}
   public function buy()
   {
	  
		$amount = $_POST['amount'];
		session()->put('paypalbalance', $amount);
		
		$str = '<form method="post" action="https://www.sandbox.paypal.com/cgi-bin/webscr" name="paypal_form"/>' . "\n";
		  if(!empty($_POST)){
			 foreach($_POST as $name => $value) {
				  $str .='<input type="hidden" name="'.$name.'" value="'.$value.'">';
				} 
		  }
        $str .= '<input type="submit" name="submit" value="Click here redirected paypal"> ';
        $str .='</form>';
        echo $str;
   }
  /* public function add_field($field, $value){
        $this->fields[$field] = $value;
    }
   public function paypal_auto_form(){
        // this function actually generates an entire HTML page consisting of
        // a form with hidden elements which is submitted to paypal via the 
        // BODY element's onLoad attribute.
        $this->button('Click here if you\'re not automatically redirected...');

        echo '<html>' . "\n";
        echo '<head><title>Processing Payment...</title></head>' . "\n";
        echo '<body style="text-align:center;" onLoad="document.forms[\'paypal_auto_form\'].submit();">' . "\n";
        echo '<p style="text-align:center;">Please wait, your order is being processed and you will be redirected to the paypal website.</p>' . "\n";
        echo $this->paypal_form('paypal_auto_form');
        echo '</body></html>';
    }
    public function paypal_form($form_name='paypal_form'){
        $str = '';
        $str .= '<form method="post" action="https://www.sandbox.paypal.com/cgi-bin/webscr" name="'.$form_name.'"/>' . "\n";
        $str .= ' <input type="hidden" name="business" value="sumit@cueserve.com"> 
		<input type="hidden" name="cmd" value="_xclick"> 
		 <input type="hidden" name="item_name" value="test watch"> 
		<input type="hidden" name="item_number" value="1">
		<input type="hidden" name="amount" value="2">   
		<input type="hidden" name="currency_code" value="USD">   
		 <input type="hidden" name="_token" value="{{ csrf_token() }}">
		<input type="hidden" name="cancel_return" value="http://localhost/04laravel/R2P/cancel"> 
		<input type="hidden" name="return" value="http://localhost/04laravel/R2P/success">
		<input type="hidden" name="notify_url" value="http://localhost/04laravel/R2P/ipn">
		<input type="submit" name="submit" value="Click here if you\'re not automatically redirected...">';
        $str .='</form>' . "\n";

        return $str;
    }
    public function button($value){
        // changes the default caption of the submit button
        $this->submit_btn ='<input type="submit" name="pp_submit" value="'.$value.'">';
    }*/
   public function ipn()
    {   
		$paypalInfo = $_POST();
		$data['user_id'] = $paypalInfo['custom'];
        $data['product_id'] = $paypalInfo["item_number"];
        $data['txn_id'] = $paypalInfo["txn_id"];
        $data['payment_gross'] = $paypalInfo["mc_gross"];
        $data['currency_code'] = $paypalInfo["mc_currency"];
        $data['payer_email'] = $paypalInfo["payer_email"];
        $data['payment_status'] = $paypalInfo["payment_status"];
       
        $paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
        $result = $this->curlPost($paypalURL,$paypalInfo);
        
        if(preg_match("/VERIFIED/i",$result)){
        }
	}
	 public function curlPost($paypalurl,$paypalreturnarr){
        $req = 'cmd=_notify-validate';
        foreach($paypalreturnarr as $key => $value){
            $value = urlencode(stripslashes($value));
            $req .= "&$key=$value";
        }
            
        $ipnsiteurl=$paypalurl;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $ipnsiteurl);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        $result = curl_exec($ch);
        curl_close($ch);
    
        return $result;
    }
    public function cancel()
    {
	    return view('paypal/cancel');
	}
	public function success()
    {
		$length = '18';
		$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$txnid = substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
		session()->put('txnid', $txnid);
		return view('paypal/success');
	}
	public function accesspayment()
	{
		$accessToken = session()->get('accessToken');
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		
		$firstName = session()->get('cfirstName');
		$last_name = session()->get('clastName');
		$userEmail = session()->get('cuserEmail');
		$txnid = session()->get('txnid');
		$mc_gross = session()->get('paypalbalance');
		$payment_status = 'Completed';
		$payment_date = date('Y-m-d H:i');
		$address_name = session()->get('caddress');
		
		
		if($flag==true){	
                $apiurl = $apiurl.'apicontroller/getfileresponse?filename=paypalvalid.json';
                $datas = array('filename'=>"paypalvalid.json");
                $senddata = json_encode($datas);
        }
        else{ 
			$paypalPayLoad = $userEmail.','.$txnid.','.$payment_status.','.$last_name.','.$address_name.','.$address_name.','.$txnid.','.$mc_gross.','.$payment_status.','.$payment_date;
            $cash = $mc_gross;
            $paymentId = $txnid;            
			
            $apiurl = config('constants.Api_Url');
            $apiurl=$apiurl.'confirmwalletcashredemption/';
            
            $userToken = session()->get('cuserToken');            
			$username = session()->get('cusername');            
            
            $partnerId = config('constants.PartnerId');
			$partnerName = config('constants.PartnerName');
            
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);
            $rewardsProgramInfo = array('paymentId'=>$paymentId , 'cash'=>$cash , 'paypalPayLoad'=>$paypalPayLoad);
            
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
            $senddata = json_encode($merge);
            
        }

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $apiurl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $senddata,
        CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        "access_token: ".$accessToken
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        
		if ($err) {
		 return redirect('cancel');
        } else {
          if(!empty($response)){
            $respe = json_decode($response);
            if(isset($respe->message)){
				return redirect('cancel');	
			}else{
                 return redirect('dashboard');	
            }             
          }              
        } 
		
	}
	
	public function validate_ipn(){
        $url_parsed = parse_url('https://www.sandbox.paypal.com/cgi-bin/webscr');    
        $post_string = '';     
        if($_POST){
            foreach ($_POST as $field=>$value){ 
                $this->ipn_data[$field] = $value;
                $post_string .= $field.'='.urlencode(stripslashes($value)).'&'; 
            }
        }
        
        $post_string.="cmd=_notify-validate"; // append ipn command

        $fp = fsockopen($url_parsed['host'],"80",$err_num,$err_str,30); 
        if(!$fp){
            
            $this->last_error = "fsockopen error no. $errnum: $errstr";
            $this->log_ipn_results(false);         
            return false;
        }else{ 
            // Post the data back to paypal
            fputs($fp, "POST $url_parsed[path] HTTP/1.1\r\n"); 
            fputs($fp, "Host: $url_parsed[host]\r\n"); 
            fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n"); 
            fputs($fp, "Content-length: ".strlen($post_string)."\r\n"); 
            fputs($fp, "Connection: close\r\n\r\n"); 
            fputs($fp, $post_string . "\r\n\r\n"); 

            // loop through the response from the server and append to variable
            while(!feof($fp))
                $this->ipn_response .= fgets($fp, 1024); 

            fclose($fp); // close connection
        }

        if(preg_match("/VERIFIED/",$this->ipn_response)){
            // Valid IPN transaction.
            $this->log_ipn_results(true);
            return true;         
        }else{
            // Invalid IPN transaction.  Check the log for details.
            $this->last_error = 'IPN Validation Failed.';
            $this->log_ipn_results(false);    
            return false;
        }
    }

    public function log_ipn_results($success){
        if (!$this->ipn_log) return;  // is logging turned off?

        // Timestamp
        $text = '['.date('m/d/Y g:i A').'] - '; 

        // Success or failure being logged?
        if ($success) $text .= "SUCCESS!\n";
        else $text .= 'FAIL: '.$this->last_error."\n";

        // Log the POST variables
        $text .= "IPN POST Vars from Paypal:\n";
        foreach ($this->ipn_data as $key=>$value)
            $text .= "$key=$value, ";

        // Log the response from the paypal server
        $text .= "\nIPN Response from Paypal Server:\n ".$this->ipn_response;

        // Write to log
        $fp=fopen($this->ipn_log_file,'a');
        fwrite($fp, $text . "\n\n"); 

        fclose($fp);  // close file
    }

    public function dump(){
        // Used for debugging, this function will output all the field/value pairs
        // that are currently defined in the instance of the class using the
        // add_field() function.
        ksort($this->fields);
        echo '<h2>ppal->dump() Output:</h2>' . "\n";
        echo '<code style="font: 12px Monaco, \'Courier New\', Verdana, Sans-serif;  background: #f9f9f9; border: 1px solid #D0D0D0; color: #002166; display: block; margin: 14px 0; padding: 12px 10px;">' . "\n";
        foreach ($this->fields as $key => $value) echo '<strong>'. $key .'</strong>:    '. urldecode($value) .'<br/>';
        echo "</code>\n";
    }
   
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}











