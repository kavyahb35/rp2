<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Product;
use App\Payment;
class PaymentController extends Controller {
    public function payment(Request $request){
           $product=Product::find($request->id);    
      return view('payment',compact('product'));
    }
    public function paymentInfo(Request $request){
		echo '<pre>';
		//print_r($request);  
		print_r($_REQUEST);
		
        if($request->tx){
            if($payment=Payment::where('transaction_id',$request->tx)->first()){
                $payment_id=$payment->id;
            }else{
                $payment=new Payment;
                $payment->item_number=$request->item_number;
                $payment->transaction_id=$request->tx;
                $payment->currency_code=$request->cc;
                $payment->payment_status=$request->st;
                $payment->save();
                $payment_id=$payment->id;
            }
        return 'Pyament has been done and your payment id is : '.$payment_id;
        
        }else{
            return 'Payment has failed';
        }
    }
    
     public function success(Request $request){
		 echo 'success';
	 }
	 public function cancel(Request $request){
		  echo 'cancel';
	 }
    public function ipn(Request $request){
		print_r($request);die;
		$data['user_id'] = $paypalInfo['custom'];
        $data['product_id'] = $paypalInfo["item_number"];
        $data['txn_id'] = $paypalInfo["txn_id"];
        $data['payment_gross'] = $paypalInfo["mc_gross"];
        $data['currency_code'] = $paypalInfo["mc_currency"];
        $data['payer_email'] = $paypalInfo["payer_email"];
        $data['payment_status'] = $paypalInfo["payment_status"];
       
        $paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
        $result = $this->curlPost($paypalURL,$paypalInfo);
        
        if(preg_match("/VERIFIED/i",$result)){
        }
	}
	
	public function curlPost($paypalurl,$paypalreturnarr){
        $req = 'cmd=_notify-validate';
        foreach($paypalreturnarr as $key => $value){
            $value = urlencode(stripslashes($value));
            $req .= "&$key=$value";
        }
            
        $ipnsiteurl=$paypalurl;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $ipnsiteurl);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        $result = curl_exec($ch);
        curl_close($ch);
    
        return $result;
    }
}
