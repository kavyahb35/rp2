<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ApiController extends Controller {
	
	
     public function getfileresponse(){     
         $filename = $_REQUEST['filename'];
            $url=config('constants.Base_Url');
             $path=$url.'fakedb/'.$filename; 
            $str = file_get_contents($path);
           return response($str, 200);           
    }
    public function getfileresponsebyclient(){     
         $filename = $_REQUEST['filename'];
            $url=config('constants.Base_Url');
             $path=$url.'jsondb/'.$filename; 
            $str = file_get_contents($path);
           return response($str, 200);           
    }
    /*
     public function deleteUser(Request $request,$id){     
        $accesskey = $request->input('AccessKey');
       
        $tag = new Appmodel();
        $chk =$tag->authenticateAPI($accesskey);
        $chk='1';
        if($chk=='1'){


         $users = DB::select('select * from hrusers where UserId = ?',[$id]);
                 if(!empty($users)){
          DB::table('hruserlogins')
              ->where('UserId', $id)
              ->update(array('Status' => '2')); 
          $error=array('Status'=>'200', 'Message'=>'User inactive Successfully.');
        }else{
           $error=array('Status'=>'400', 'Message'=>'User not exist.');
        }

        }else{
          $error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
         return response()->json($error, 201);
    }*/
	

}












