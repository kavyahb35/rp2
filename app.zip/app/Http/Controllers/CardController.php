<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class CardController extends Controller {
    public function index()
    {
		
        $data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
		
		    
        if($flag==true){          
            $apiurl = $apiurl.'apicontroller/getfileresponse?filename=allprogramlist.json';
			$datas = array('filename'=>"allprogramlist.json");
			$senddata = json_encode($datas);
            
            $apiurl1 = config('constants.Api_Url');
            $apiurl1 = $apiurl1.'apicontroller/getfileresponse?filename=userprogramlistmy.json';
            $senddata1 = array('filename'=>"userprogramlistmy.json");
        }
        else{
			$partnerId = config('constants.PartnerId');
			$partnerName = config('constants.PartnerName');
            
			
            $apiurl  = $apiurl.'getloyaltyprograminfo/';
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);         
            $senddata = json_encode($partnerInfo); 
            
            $apiurl1 =config('constants.Api_Url');
            $apiurl1 = $apiurl1.'fetchUserRewards/';
            
            $partnerInfo1 = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials1 = array('userName'=>$username ,'userToken'=>$userToken);
            $merge1 = array('partnerInfo'=>$partnerInfo1,'credentials'=>$credentials1);
            $senddata1 = json_encode($merge1);

        }  
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        
        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($response)){
             $respe = json_decode($response); 
             
          }              
        }
        // -- for get perticular user  program
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiurl1,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $senddata1,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
          ),
        ));

        $responses = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($responses)){
             $respes = json_decode($responses); 
             
          }              
        }
        
         if(!empty($respes)){
			$data['withoutLoginProgram'] = $this->array_diff_assoc_recursive($respe, $respes);    
		}else{
			foreach($respe as $evh){
			 $newsarray[] = array(
                        'progId'=>$evh->progId,
                        'programName'=>$evh->programName,
                        'minPointsEntered'=>$evh->minPointsEntered,
                        'activeStatus'=>$evh->activeStatus,
                        'canManage'=>$evh->canManage,
                        'canMonitor'=>$evh->canMonitor,
                        'country'=>$evh->country,
                        'canRedeem'=>$evh->canRedeem,
                        'barcodeStandard'=>$evh->barcodeStandard             
                    );
				}
			$data['withoutLoginProgram'] = $newsarray;  
		}
		
		
		 
		$data['loginProgram'] =$respes;   
		
		return view('customer/afterlogin/manage_cards',$data);
    }
     function array_diff_assoc_recursive($array1, $array2)
    {     
        
        foreach($array1 as $aV){ 
            $aTmp1[] = $aV->progId;
        }

        foreach($array2 as $aV){
            $aTmp2[] = $aV->progId;
        }
  
        $new_array = array_diff($aTmp1,$aTmp2);   
       
        $new_array = array_values($new_array); 
        $i=0;
        foreach($array1 as $x => $news){
			$progid = $news->progId;
			 if (in_array($progid, $new_array)) {
                $newsarray[] = array(
                    'progId'=>$news->progId,
                    'programName'=>$news->programName,
                    'minPointsEntered'=>$news->minPointsEntered,
                    'activeStatus'=>$news->activeStatus,
                    'canManage'=>$news->canManage,
                    'canMonitor'=>$news->canMonitor,
                    'country'=>$news->country,
                    'canRedeem'=>$news->canRedeem,
                    'barcodeStandard'=>$news->barcodeStandard             
                );
            }
        $i++;
        }
        
       return $newsarray;
    }
    /*function array_diff_assoc_recursive($array1, $array2)
    {     
        
        foreach($array1 as $aV){ 
            $aTmp1[] = $aV->progId;
        }

        foreach($array2 as $aV){
            $aTmp2[] = $aV->progId;
        }
  
        $new_array = array_diff($aTmp1,$aTmp2);
        $n =array_values($new_array);
        $co = count($n);
        $mn =$co-1;
        $i=0;
        foreach($array1 as $news){ 
                if (in_array($n[$i], $aTmp1)) {
                    $newsarray[] = array(
                        'progId'=>$news->progId,
                        'programName'=>$news->programName,
                        'minPointsEntered'=>$news->minPointsEntered,
                        'activeStatus'=>$news->activeStatus,
                        'canManage'=>$news->canManage,
                        'canMonitor'=>$news->canMonitor,
                        'country'=>$news->country,
                        'canRedeem'=>$news->canRedeem,
                        'barcodeStandard'=>$news->barcodeStandard             
                    );
                    
                }
                if($i==$mn){
					return $newsarray;
			   }
            $i++;
        }  //print_r($newsarray);die;
      
       return $newsarray;

    }*/
    
    public function addProgram()
    {
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
		
        if($accessToken=='')
        {
                 $tag = new Appmodel();
                 $tag->authgenerate();  
        }
        if($_POST){
			$programid = $_POST['programid'];
			$programidname = $_POST['programidname'];
			$progUsername = $_POST['username'];
			$progPwd = $_POST['password'];
			
			if($flag==true){	
				$apiurl = $apiurl.'apicontroller/getfileresponse?filename=addrewardsprogramvalid.json';
				$datas = array('filename'=>"addrewardsprogramvalid.json");
				$senddata = json_encode($datas);
			}
			else{
				
                
				$apiurl  = $apiurl.'addUserRewards/';
				$partnerId = config('constants.PartnerId');
				$partnerName = config('constants.PartnerName');
				
				$partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                $credentials = array('userName'=>$username ,'userToken'=>$userToken);
                $rewardsProgramInfo = array('progId'=>$programid,'progUsername'=>$progUsername,'progPwd'=>$progPwd);
                $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardsProgramInfo'=>$rewardsProgramInfo);
                $senddata = json_encode($merge);
			}
			 $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $apiurl,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => $senddata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
              ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);
           if ($err) {
             $data['error']=$err;
             $data['err'] ='2';
             echo json_encode($data);
            } else {
              if(!empty($response)){
                  
                 $respe = json_decode($response);
                 if(isset($respe->faultstring)){
				   $data['error'] = 'please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                   $data['err'] = '2'; 
				 }elseif(isset($respe->message)){
					  $data['error'] = $respe->message;
                   $data['err'] = '2'; 
				}
				 else{
					if(isset($respe->progId)){
                            $data['success'] = $programidname .' program added successfully.'; $data['succ']='1';
                             $data['succ'] = '1'; 
                    } 
			     }
					echo json_encode($data);
                 
               
              }

            }
		}
			
	}
	public function addCardProgram()
	{
	   
		$data['success'] ='';
		$data['error'] ='';
		$tag = new Appmodel();
		$tag->checkCustomerAuthenticate();
		$accessToken = session()->get('accessToken');
		$userToken = session()->get('cuserToken');
		$apiurl = config('constants.Api_Url');
		$flag = config('constants.Usedstaticdata');
		$username = session()->get('cusername');
		$coldpassword = session()->get('coldpassword');
		
		
        if($accessToken=='')
        {
            $tag = new Appmodel();
            $tag->authgenerate();  
        }
        if($_POST){
			$programid = $_POST['programid'];
			$programidname = $_POST['programidname'];
			$cardnumber = $_POST['cardnumber'];
			
			if($flag==true){	
				$apiurl = $apiurl.'apicontroller/getfileresponse?filename=add_updatecardvalid.json';
				$datas = array('filename'=>"add_updatecardvalid.json");
				$senddata = json_encode($datas);
			}
			else{
				
                
				$apiurl  = $apiurl.'updatecardnumber/';
				$partnerId = config('constants.PartnerId');
				$partnerName = config('constants.PartnerName');
			    
                $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                $credentials = array('userName'=>$username ,'userToken'=>$userToken);
                $rewardsProgramInfo = array('progId'=>$programid,'cardNumber'=>$cardnumber);
                $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardsProgramInfo'=>$rewardsProgramInfo);
                $senddata = json_encode($merge);
			}
			 $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $apiurl,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => $senddata,
              CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
              ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);
           if ($err) {
             $data['error']=$err;
             $data['err'] ='2';
             echo json_encode($data);
            } else {
              if(!empty($response)){
                 $respe = json_decode($response);
                 
                 
                 //$errormsg = $respe->message;
                 if(isset($respe->statusCode)){
                     
                         if($respe->statusCode=='1'){
                             $data['success']=$programidname .' program added successfully.';
                             $data['succ']='1';
                         }else if($respe->statusCode=='0'){
							  $data['error']=$respe->statusMessage;
                             $data['err']='2';
						}
                       else{
                           $contact = base_url();
                        $data['error']='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                            $data['err']='2';
                        }
                     
                     
                 }
                
                 echo json_encode($data);
              }

            }
		}
	}
    
     

}











