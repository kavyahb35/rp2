<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
/*
Route::get('/', function () {
    return view('welcome');
}); */

Route::get('paypalform','PaymentController@payment');

Route::get('payment-status',array('as'=>'payment.status','uses'=>'PaymentController@paymentInfo'));
Route::get('payment',array('as'=>'payment','uses'=>'PaymentController@payment'));
Route::get('payment-cancel', function () {
    return 'Payment has been canceled';
});

/* Front Page */
Route::get('/', 'FrontController@index');
Route::get('index', 'FrontController@index');
Route::Post('front/contact','FrontController@contact');


/* User Access Befor Login */
Route::Post('apicontroller/getfileresponse','ApiController@getfileresponse');
Route::get('sign-in','UserController@index');
Route::Post('sign-in','UserController@index');
Route::get('dashboard','UserController@dashboard');

Route::get('forgot-password','UserController@forgotpasword');
Route::Post('forgot-password','UserController@forgotpasword');

Route::get('update-password/{id}/{ids}','UserController@updateresetPassword');

Route::Post('update-password/{id}/{ids}','UserController@updateresetPassword');


Route::get('sign-up','UserController@register');
Route::Post('sign-up','UserController@register');


Route::get('dashboard','UserController@dashboard');

Route::get('logout','UserController@logout');
Route::get('profile','UserController@profile');
Route::Post('update-profile','UserController@updateprofile');

Route::get('change-password','UserController@changepassword');
Route::get('updatepassword','UserController@updatepassword');
Route::Post('updatepassword','UserController@updatepassword');

Route::get('manage-cards','CardController@index');
Route::Post('CardController/addProgram','CardController@addProgram');

Route::Post('CardController/addCardProgram','CardController@addCardProgram');
Route::get('transaction','TransactionController@index');
Route::Post('transaction','TransactionController@index');

Route::get('wallet','WalletController@index');
Route::Post('wallet/refreshpoins','WalletController@refreshpoins');
Route::Post('wallet/removepoins','WalletController@removepoins');
Route::Post('wallet/redeemvaluefuncion','WalletController@redeemvaluefuncion');
Route::Post('wallet/cashvaluefuncion','WalletController@cashvaluefuncion');



/* Paypal routes */
Route::get('paycart','PaypalController@index');
Route::Post('buy','PaypalController@buy');
Route::get('ipn','PaypalController@ipn');
Route::Post('ipn','PaypalController@ipn');
Route::get('success','PaypalController@success');
Route::any('success','PaypalController@success');
Route::get('cancel','PaypalController@cancel');
Route::get('cancel','PaypalController@cancel');
Route::get('accesspayment','PaypalController@accesspayment');
Route::Post('accesspayment','PaypalController@accesspayment');



